@echo off
cd /d "%~dp0"
py -3 -m pip install --upgrade pyinstaller
py -3 -m PyInstaller --onefile --windowed --name MAA_to_CST_2026_UA1CFM maa_to_cst2026.py
if errorlevel 1 pause
