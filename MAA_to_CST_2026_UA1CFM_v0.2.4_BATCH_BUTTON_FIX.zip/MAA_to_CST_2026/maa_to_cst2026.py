#!/usr/bin/env python3
"""MMANA .MAA to CST Studio Suite 2026 VBA macro generator.
Conservative beta: geometry reliable by parsing, ports only safe center cases, loads audited.
"""
from __future__ import annotations
import argparse,csv,json,math,re,sys
from pathlib import Path

VERSION='0.2.4'
TOKEN=re.compile(r'^w(\d+)([bce])([+-]\d+)?$',re.I)
def parse_file(path):
    data=Path(path).read_bytes()
    text=None
    for enc in ('utf-8-sig','cp1251','latin1'):
        try: text=data.decode(enc);break
        except UnicodeDecodeError: continue
    lines=[l.strip() for l in text.replace('\r','\n').split('\n') if l.strip()]
    def label(line):
        raw=line.strip().strip('*').strip().lower().replace(' ','').replace('.','')
        if raw in ('wires','провода','проводники'):return 'wires'
        if raw in ('source','источ','источник','источники'):return 'source'
        if raw in ('load','нагрузка','нагрузки'):return 'load'
        return None
    headers={}
    for i,l in enumerate(lines):
        k=label(l)
        if k and k not in headers:headers[k]=i
    if 'wires' not in headers:raise ValueError('No recognized wires section (*Wires* / *Провода*)')
    idx=headers['wires']
    try:freq=float(lines[idx-1].replace(',','.'))
    except Exception:raise ValueError('Invalid frequency before wires section')
    if not math.isfinite(freq) or not 0<freq<1e6:raise ValueError('Invalid frequency')
    n=int(float(lines[idx+1].split(',')[0].strip()))
    warnings=[];wires=[]
    for j in range(n):
        try:
            ln=lines[idx+2+j];x=[v.strip() for v in ln.split(',')]
            if len(x)<8:raise ValueError('too few columns')
            vals=[float(t) for t in x[:7]];seg=int(float(x[7]));a=tuple(vals[:3]);b=tuple(vals[3:6]);r=vals[6]
            if not all(math.isfinite(v) for v in vals):raise ValueError('nonfinite coordinate or radius')
            if math.dist(a,b)<1e-10:raise ValueError('zero-length wire')
            if abs(r)<1e-12:raise ValueError('zero radius — not substituted')
            if r<0:warnings.append(f'Wire {j+1}: negative signed MAA radius {r:g}; using absolute physical radius {abs(r):g} (verify original semantics)')
            wires.append({'a':a,'b':b,'r':abs(r),'seg':seg})
        except Exception as ex:
            warnings.append(f'Wire {j+1}: NOT EXPORTED: {ex}')
            wires.append(None)
    def records(section):
        k=headers.get(section)
        if k is None:return []
        try:count=int(float(lines[k+1].split(',')[0].strip()))
        except Exception:
            warnings.append(f'{section}: invalid record count');return []
        result=[]
        for j in range(count):
            try:result.append([x.strip() for x in lines[k+2+j].split(',')])
            except Exception as ex:warnings.append(f'{section} record {j+1}: {ex}')
        return result
    return {'name':lines[0] if idx>2 else Path(path).stem,'freq':freq,'wires':wires,'sources':records('source'),'loads':records('load'),'path':str(path),'parse_warnings':warnings}

def position(w, tag, frequency_mhz=145.0):
    m=TOKEN.fullmatch(tag.lower().replace(' ',''))
    if not m:return None,'bad pulse token'
    idx=int(m[1])-1
    if not (0<=idx<len(w)):return None,'wire number out of range'
    if w[idx] is None:return None,'source/load references a non-exportable wire'
    wire=w[idx];seg=wire['seg'];where=m[2];offset=int(m[3] or 0)
    if offset:
        return None,'indexed pulse offsets require MMANA segmentation reconstruction'
    if where=='c':return (idx,0.5),'center pulse'
    length=math.dist(wire['a'],wire['b'])
    if seg>0:
        t=0.5/seg if where=='b' else 1-0.5/seg
        return (idx,t),'end pulse midpoint, explicit equal segmentation (verify MMANA method)'
    # Conservative geometry approximation; NOT claimed as exact MMANA pulse position.
    wavelength=299.792458/frequency_mhz
    first_seg=min(length/7.0,wavelength/40.0)
    t=(first_seg/2.0)/length
    return (idx,t if where=='b' else 1-t),'APPROXIMATE auto-segmented endpoint; compare with MMANA pulse position'

def xyz(w,t):return tuple((1-t)*a+t*b for a,b in zip(w['a'],w['b']))
def num(v):return f'{v:.10g}'
def vq(v):return ', '.join('"'+num(x)+'"' for x in v)
def emit(model, port_gap_ratio=0.4, port_impedance=50, sweep_percent=5.0):
    if not math.isfinite(sweep_percent) or not (0 < sweep_percent < 100):
        raise ValueError("Sweep percent must be > 0 and < 100")
    center_ghz=model["freq"]/1000.0
    fmin_ghz=center_ghz*(1-sweep_percent/100)
    fmax_ghz=center_ghz*(1+sweep_percent/100)
    wirelist=model['wires']; cuts={}; issues=[{'kind':'geometry','status':'WARNING','reason':x} for x in model.get('parse_warnings',[])]; ports=[]; loads=[]
    def addcut(wi,t,kind,idx,token,record=None):
        w=wirelist[wi];length=math.dist(w['a'],w['b'])
        gap=min(0.8*w['r'],length*0.03)
        # Keep gaps separate even when one wire has source + load(s).
        center=xyz(w,t)
        for j,other in enumerate(wirelist):
            if j==wi or other is None:continue
            ap,bp=other['a'],other['b'];d=tuple(b-a for a,b in zip(ap,bp));dd=sum(x*x for x in d)
            u=min(1,max(0,sum((x-a)*di for x,a,di in zip(center,ap,d))/dd))
            if math.dist(xyz(other,u),center) <= other['r']+w['r']*0.3:
                return None,'neighboring conductor intersects element gap (wire '+str(j+1)+')'
        start=t-gap/(2*length);stop=t+gap/(2*length)
        if start<=0 or stop>=1:return None,'electrical gap exceeds available endpoint length'
        for cut in cuts.get(wi,[]):
            if start <= cut['stop']+1e-7 and stop>=cut['start']-1e-7:
                return None,'overlapping port/load gaps on same wire'
        cut={'start':start,'stop':stop,'p1':xyz(w,start),'p2':xyz(w,stop),'kind':kind,'index':idx,'pulse':token}
        cuts.setdefault(wi,[]).append(cut)
        return cut,None
    for si,record in enumerate(model['sources'],1):
        token=record[0].lower() if record else ''
        found,status=position(wirelist,token,model['freq'])
        if found is None:
            issues.append({'kind':'source','index':si,'pulse':token,'status':'NOT_CREATED','reason':status});continue
        wi,t=found
        cut,reason=addcut(wi,t,'source',si,token,record)
        if reason:
            issues.append({'kind':'source','index':si,'pulse':token,'status':'NOT_CREATED','reason':reason});continue
        ports.append({'number':si,'pulse':token,'p1':cut['p1'],'p2':cut['p2'],'note':status,'voltage':record[2] if len(record)>2 else '1','phase':record[1] if len(record)>1 else '0'})
        if 'APPROXIMATE' in status: issues.append({'kind':'source','index':si,'pulse':token,'status':'APPROXIMATE_POSITION','reason':status})
    for li,record in enumerate(model['loads'],1):
        token=record[0].lower() if record else ''
        found,status=position(wirelist,token,model['freq'])
        if found is None:
            issues.append({'kind':'load','index':li,'pulse':token,'status':'NOT_CREATED','reason':status,'record':record});continue
        try:
            kind=int(float(record[1]));values=[float(x) for x in record[2:]]
            if kind==0:
                lu,cp,q=values[:3]
                if lu<0 or cp<0 or q<0:raise ValueError('negative L/C/Q')
                if lu>0 and cp>0:raise ValueError('parallel LC requires special circuit model')
                if q>0:raise ValueError('finite Q requires loss model')
                if not lu and not cp:raise ValueError('empty LC')
                r,lh,cf=0.0,lu*1e-6,cp*1e-12
            elif kind==1:
                r,xx=values[:2]
                if r<=0 or xx:raise ValueError('R+jX complex load unsupported without approximation')
                lh=cf=0.0
            else:raise ValueError('unsupported load type')
        except (ValueError,IndexError) as ex:
            issues.append({'kind':'load','index':li,'pulse':token,'status':'NOT_CREATED','reason':str(ex),'record':record});continue
        wi,t=found
        cut,reason=addcut(wi,t,'load',li,token,record)
        if reason:
            issues.append({'kind':'load','index':li,'pulse':token,'status':'NOT_CREATED','reason':reason,'record':record});continue
        loads.append({'index':li,'pulse':token,'p1':cut['p1'],'p2':cut['p2'],'R_ohm':r,'L_H':lh,'C_F':cf,'original':record,'position_note':status})
        if 'APPROXIMATE' in status: issues.append({'kind':'load','index':li,'pulse':token,'status':'APPROXIMATE_POSITION','reason':status,'record':record})
    lines=["' MAA -> CST Studio Suite 2026 | UA1CFM | 2026",f"' Generator version {VERSION}","' Source: "+Path(model['path']).name,f"' MMANA center frequency: {num(model['freq'])} MHz",f"' Sweep: {num(fmin_ghz*1000)} .. {num(fmax_ghz*1000)} MHz (+/- {num(sweep_percent)}%)","' Polygon3D -> CurveWire from user-supplied CST 2026 History List.","' Loads: ideal R,L,C at B/C/E; auto-segmented endpoint positions are approximate","' Use a NEW EMPTY Microwave Studio project in CST 2026.","Sub Main()",'    With Units','        .Geometry "mm"','        .Frequency "GHz"','    End With','    Solver.FrequencyRange "'+num(fmin_ghz)+'", "'+num(fmax_ghz)+'"','','    With FDSolver','        .Reset','        .SetMethod "Surface", "General purpose"','        .OrderSrf "First"','        .Stimulation "All", "All"','        .SweepMinimumSamples "10"','        .SetNumberOfResultDataSamples "1001"','        .SetResultDataSamplingMode "Automatic"', '        .AddSampleInterval "'+num(fmin_ghz)+'", "'+num(fmax_ghz)+'", "25", "Automatic", "False"', '        .AddSampleInterval "'+num(center_ghz)+'", "'+num(center_ghz)+'", "1", "Single", "False"','    End With','']
    lines.append('')
    for i,w in enumerate(wirelist,1):
        if w is None:continue
        pieces=[]
        last=0.0
        for cut in sorted(cuts.get(i-1,[]),key=lambda v:v['start']):
            if cut['start']>last+1e-9:pieces.append((xyz(w,last),xyz(w,cut['start'])))
            last=cut['stop']
        if last<1.0-1e-9:pieces.append((xyz(w,last),xyz(w,1.0)))
        for k,(a,b) in enumerate(pieces,1):
            tag=f'W{i:04d}' + (f'_{k}' if len(pieces)>1 else '')
            curve_name='MAA_Curves'
            poly_name='poly_'+tag
            wire_name='wire_'+tag
            # CST 2026 syntax supplied directly from a working History List:
            # Polygon3D: .Version 10 / .Point x,y,z / .Create
            # Wire: .Type "CurveWire" / .Curve "folder:polygon" / .Add
            lines+=['    With Polygon3D','        .Reset','        .Version 10',f'        .Name "{poly_name}"',f'        .Curve "{curve_name}"',f'        .Point {vq(tuple(x*1000 for x in a))}',f'        .Point {vq(tuple(x*1000 for x in b))}','        .Create','    End With','']
            lines+=['    With Wire','        .Reset',f'        .Name "{wire_name}"',f'        .Folder "{curve_name}"',f'        .Radius "{num(w["r"]*1000)}"','        .Type "CurveWire"',f'        .Curve "{curve_name}:{poly_name}"','        .Material "PEC"','        .SolidWireModel "False"','        .Termination "Natural"','        .Mitering "NewMiter"','        .AdvancedChainSelection "True"','        .Add','    End With','']
    for p in ports:
        lines+=['    With DiscretePort','        .Reset','        .Type "SParameter"',f'        .PortNumber "{p["number"]}"',f'        .SetP1 "False", {vq(tuple(x*1000 for x in p["p1"]))}',f'        .SetP2 "False", {vq(tuple(x*1000 for x in p["p2"]))}',f'        .Impedance "{num(port_impedance)}"','        .Create','    End With','']
    for ld in loads:
        # Complete CST LumpedElement properties based on published CST VBA example.
        # This is not a guarantee of compatibility with a specific CST 2026 installation.
        # CST SetType selects the circuit topology, not an individual part.
        # Ideal single R/L/C is represented by the corresponding nonzero
        # value in the series RLC network.
        lines += [
            '    With LumpedElement',
            '        .Reset',
            f'        .SetName "MAA_Load_{ld["index"]}"',
            '        .Folder "MAA_Loads"',
            '        .SetType "RLCSerial"',
            f'        .SetR "{num(ld["R_ohm"])}"',
            f'        .SetL "{num(ld["L_H"])}"',
            f'        .SetC "{num(ld["C_F"])}"',
            '        .SetGs "0"',
            '        .SetI0 "1e-14"',
            '        .SetT "300"',
            '        .SetMonitor "True"',
            '        .SetRadius "1"',
            '        .CircuitFileName ""',
            '        .CircuitId "1"',
            '        .UseCopyOnly "True"',
            '        .UseRelativePath "False"',
            f'        .SetP1 "False", {vq(tuple(x*1000 for x in ld["p1"]))}',
            f'        .SetP2 "False", {vq(tuple(x*1000 for x in ld["p2"]))}',
            '        .SetInvert "False"',
            '        .Wire ""',
            '        .Position "end1"',
            '        .Create',
            '    End With',
            ''
        ]
    lines += [
        '    MsgBox "Imported '+str(len(wirelist))+' wires, '+str(len(ports))+' port(s), '+str(len(loads))+' load command(s). Check CST Navigation Tree / Lumped Elements to verify actual creation.", vbInformation, "MAA to CST 2026"',
        'End Sub', ''
    ]
    audit={'version':VERSION,'input':model['path'],'name':model['name'],'wire_count':len(wirelist),'wire_exported_count':sum(w is not None for w in wirelist),'parse_warnings':model.get('parse_warnings',[]),'source_count':len(model['sources']),'port_count':len(ports),'load_count':len(model['loads']),'load_imported':len(loads),'load_vba_emitted':len(loads),'load_verified_in_cst':False,'end_pulse_position_is_approximate':any(x['status']=='APPROXIMATE_POSITION' for x in issues),'fully_equivalent':False,'ports':ports,'imported_loads':loads,'issues':issues,'units':{'MAA':'m','CST':'mm'},'frequency_mhz':model['freq'],'sweep_percent':sweep_percent,'sweep_start_mhz':fmin_ghz*1000,'sweep_stop_mhz':fmax_ghz*1000,'fd_solver_sample_interval':'Automatic','fd_solver_sweep_parameter':'25','mesh_configuration':'not_generated_user_controls_in_CST','fd_solver_center_sample_ghz':center_ghz}
    return '\n'.join(lines),audit

def convert_file(src,dest,sweep_percent=5.0):
    model=parse_file(src);macro,audit=emit(model,sweep_percent=sweep_percent);dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(macro,encoding='utf-8-sig');dest.with_suffix('.audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8');return audit

def batch(root,out,sweep_percent=5.0,progress=None):
    root=Path(root);out=Path(out)
    items=sorted((p for p in root.rglob('*') if p.is_file() and p.suffix.lower()=='.maa'),key=lambda p:str(p).casefold())
    out.mkdir(exist_ok=True,parents=True)
    rows=[]
    if progress:progress(0,len(items),None)
    for p in items:
        rel=p.relative_to(root);dst=out/rel.with_suffix('.bas');entry={'file':str(rel),'bas':str(dst.relative_to(out))}
        try:
            audit=convert_file(p,dst,sweep_percent)
            entry.update({'status':'OK' if not audit['issues'] else 'WARNINGS','wires':audit['wire_count'],'exported_wires':audit['wire_exported_count'],'sources':audit['source_count'],'ports':audit['port_count'],'loads':audit['load_count'],'exported_loads':audit['load_imported'],'issue_count':len(audit['issues']),'frequency_mhz':audit['frequency_mhz'],'sweep_start_mhz':audit['sweep_start_mhz'],'sweep_stop_mhz':audit['sweep_stop_mhz']})
        except Exception as e:
            # Never silently lose an input: place a clearly marked diagnostic .bas and report.
            dst.parent.mkdir(parents=True,exist_ok=True)
            error=str(e)
            dst.write_text("' FAILED TO CONVERT MAA: " + p.name.replace("\n",' ') + "\n' " + error.replace("\n",' ') + "\nSub Main()\n    MsgBox " + json.dumps('MAA conversion failed: '+error,ensure_ascii=True) + ", vbCritical, " + json.dumps('MAA to CST - NOT CONVERTED') + "\nEnd Sub\n",encoding='utf-8-sig')
            entry.update({'status':'ERROR','error':error})
        rows.append(entry)
        if progress:progress(len(rows),len(items),entry)
    fieldnames=['file','bas','status','wires','exported_wires','sources','ports','loads','exported_loads','issue_count','frequency_mhz','sweep_start_mhz','sweep_stop_mhz','error']
    with (out/'BATCH_REPORT.csv').open('w',newline='',encoding='utf-8-sig',errors='replace') as f:
        writer=csv.DictWriter(f,fieldnames=fieldnames);writer.writeheader();writer.writerows(rows)
    with (out/'FAILED_AND_WARNINGS.txt').open('w',encoding='utf-8') as f:
        for r in rows:
            if r['status']!='OK':f.write(r['status']+' | '+r['file']+' | '+r.get('error',f"{r.get('issue_count',0)} warning(s)")+'\n')
    return rows

def gui():
    import tkinter as tk
    from tkinter import filedialog,messagebox,ttk
    import threading,queue
    win=tk.Tk();win.title('MAA → CST Studio Suite 2026 | UA1CFM 2026 | v'+VERSION);win.geometry('785x400')
    tk.Label(win,text='MMANA .MAA → CST 2026 .BAS',font=('Segoe UI',16,'bold')).pack(pady=12)
    source=tk.StringVar();output=tk.StringVar();mode=tk.StringVar(value='folder');sweep_var=tk.StringVar(value='5')
    info=tk.StringVar(value='Выберите папку MAA, затем нажмите «НАЧАТЬ КОНВЕРТАЦИЮ»')
    stats=tk.StringVar(value='Ожидание');pct=tk.StringVar(value='0%')
    frm=tk.Frame(win);frm.pack(fill='x',padx=15)
    def browse_src():
        if mode.get()=='folder':sel=filedialog.askdirectory(title='Выберите папку с MAA')
        else:sel=filedialog.askopenfilename(filetypes=[('MMANA antenna','*.maa'),('All files','*.*')])
        if sel:source.set(sel)
    def browse_out():
        sel=filedialog.askdirectory(title='Выберите папку для BAS')
        if sel:output.set(sel)
    choices=tk.Frame(frm);choices.pack(anchor='w')
    tk.Radiobutton(choices,text='Папка MAA (включая подпапки)',variable=mode,value='folder').pack(side='left')
    tk.Radiobutton(choices,text='Один файл MAA',variable=mode,value='file').pack(side='left',padx=20)
    for label,var,func in [('Вход:',source,browse_src),('Выход:',output,browse_out)]:
        row=tk.Frame(frm);row.pack(fill='x',pady=5)
        tk.Label(row,text=label,width=8,anchor='w').pack(side='left')
        tk.Entry(row,textvariable=var).pack(side='left',fill='x',expand=True)
        tk.Button(row,text='Обзор...',command=func,width=12).pack(side='left',padx=6)
    row=tk.Frame(frm);row.pack(anchor='w',pady=7)
    tk.Label(row,text='Sweep ± (%)').pack(side='left');tk.Entry(row,textvariable=sweep_var,width=9).pack(side='left',padx=10)
    bar=ttk.Progressbar(win,maximum=100,mode='determinate',length=720);bar.pack(pady=(13,4))
    tk.Label(win,textvariable=pct,font=('Segoe UI',12,'bold')).pack()
    tk.Label(win,textvariable=stats).pack(pady=3)
    tk.Label(win,textvariable=info,wraplength=740).pack(pady=3)
    events=queue.Queue();start_btn=None
    def poll():
        try:
            while True:
                typ,obj=events.get_nowait()
                if typ=='progress':
                    done,total,row=obj;percentage=100*done/total if total else 100
                    bar['value']=percentage;pct.set(f'{percentage:.1f}% ({done}/{total})')
                    if row:info.set(row['file']+' — '+row['status'])
                elif typ=='done':
                    start_btn.config(state='normal');stats.set(obj);info.set('Отчёты: BATCH_REPORT.csv и FAILED_AND_WARNINGS.txt')
                elif typ=='error':
                    start_btn.config(state='normal');info.set(obj);messagebox.showerror('Ошибка',obj)
        except queue.Empty:pass
        win.after(80,poll)
    def start():
        src=Path(source.get());dst=Path(output.get());
        if not src.exists() or not output.get():messagebox.showerror('Ошибка','Укажи существующий вход и папку результата');return
        try:
            sw=float(sweep_var.get().replace(',','.'))
            if not 0<sw<100:raise ValueError('Sweep должен быть между 0 и 100')
        except ValueError as exc:messagebox.showerror('Ошибка',str(exc));return
        selected_mode=mode.get()
        start_btn.config(state='disabled');bar['value']=0;pct.set('0%');info.set('Конвертация...')
        def worker():
            try:
                if selected_mode=='folder':
                    rows=batch(src,dst,sw,lambda d,t,e:events.put(('progress',(d,t,e))))
                    ok=sum(r['status']=='OK' for r in rows);warnings=sum(r['status']=='WARNINGS' for r in rows);errors=sum(r['status']=='ERROR' for r in rows)
                    events.put(('done',f'Всего {len(rows)} | без замечаний {ok} | с предупреждениями {warnings} | ошибок {errors}'))
                else:
                    result=convert_file(src,dst/(src.stem+'.bas'),sw)
                    events.put(('progress',(1,1,{'file':src.name,'status':'OK'})))
                    events.put(('done',f'Создан {src.stem}.bas | проводников {result["wire_exported_count"]} | замечаний {len(result["issues"])}'))
            except Exception as ex:events.put(('error',str(ex)))
        threading.Thread(target=worker,daemon=True).start()
    start_btn=tk.Button(win,text='▶ НАЧАТЬ КОНВЕРТАЦИЮ',font=('Segoe UI',12,'bold'),width=32,command=start)
    start_btn.pack(pady=10)
    tk.Label(win,text='© UA1CFM 2026  |  Polygon3D + Wire  |  Mesh регулируется вручную в CST',fg='gray').pack()
    win.after(80,poll);win.mainloop()

def main():
    ap=argparse.ArgumentParser(description='MAA → CST Studio 2026 VBA .bas generator')
    ap.add_argument('--input',help='Single MAA file');ap.add_argument('--output',help='Output BAS file');ap.add_argument('--sweep-percent',type=float,default=5.0,help='Half-width of frequency sweep in percent (default: 5)');ap.add_argument('--batch',help='MAA input folder');ap.add_argument('--outdir',help='Output folder');a=ap.parse_args()
    if a.batch:print('Converted',len(batch(a.batch,a.outdir or 'CST_Macros',a.sweep_percent)),'files')
    elif a.input:print(json.dumps(convert_file(a.input,a.output or Path(a.input).with_suffix('.bas'),a.sweep_percent),ensure_ascii=False,indent=2))
    else:gui()
if __name__=='__main__':main()
