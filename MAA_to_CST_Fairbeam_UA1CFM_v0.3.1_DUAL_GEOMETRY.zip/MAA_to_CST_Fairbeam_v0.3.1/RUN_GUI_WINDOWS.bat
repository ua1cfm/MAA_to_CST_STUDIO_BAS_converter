@echo off
cd /d "%~dp0"
py -3 maa_to_cst2026.py
if errorlevel 1 pause
