﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' GEOMETRY ONLY; NO PORTS / NO LOADS / NO CUTS / NO ADJUSTMENTS
' Generator version 0.3.1-DUAL-EXPORT
' Source: hornYagi-2.maa
' MMANA frequency: 145 MHz
' Frequency sweep: 137.75 to 152.25 MHz
' Original MAA wire endpoints are preserved (meters -> millimeters).
' Manual CST mesh settings; existing project geometry is NOT deleted.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.13775", "0.15225"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.13775", "0.15225", "25", "Automatic", "False"
        .AddSampleInterval "0.145", "0.145", "1", "Single", "False"
    End With

    ' Wire 1: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001"
        .Curve "MAA_Curves"
        .Point "-400", "574", "0"
        .Point "-400", "-574", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 2: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "300", "471.5", "-100"
        .Point "300", "-471.5", "-100"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 3: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "300", "471.5", "100"
        .Point "300", "-471.5", "100"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 4: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "600", "465", "250"
        .Point "600", "-465", "250"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 5: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "600", "465", "-250"
        .Point "600", "-465", "-250"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 6: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "950", "462.5", "-400"
        .Point "950", "-462.5", "-400"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 7: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "950", "462.5", "400"
        .Point "950", "-462.5", "400"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 8: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "1400", "460", "550"
        .Point "1400", "-460", "550"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 9: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009"
        .Curve "MAA_Curves"
        .Point "1400", "460", "-550"
        .Point "1400", "-460", "-550"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 10: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010"
        .Curve "MAA_Curves"
        .Point "1950", "457.5", "580"
        .Point "1950", "-457.5", "580"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 11: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "1950", "457.5", "-580"
        .Point "1950", "-457.5", "-580"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 12: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "2470", "455", "580"
        .Point "2470", "-455", "580"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 13: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013"
        .Curve "MAA_Curves"
        .Point "2470", "455", "-580"
        .Point "2470", "-455", "-580"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 14: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0014"
        .Curve "MAA_Curves"
        .Point "0", "491", "0"
        .Point "0", "-491", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0014"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0014"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 15: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0015"
        .Curve "MAA_Curves"
        .Point "-400", "574", "400"
        .Point "-400", "-574", "400"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0015"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0015"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 16: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0016"
        .Curve "MAA_Curves"
        .Point "-400", "574", "-400"
        .Point "-400", "-574", "-400"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0016"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0016"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    MsgBox "Created 16 complete Wire objects (geometry only). No ports, loads or cuts.", vbInformation, "MAA to CST Geometry Only"
End Sub
