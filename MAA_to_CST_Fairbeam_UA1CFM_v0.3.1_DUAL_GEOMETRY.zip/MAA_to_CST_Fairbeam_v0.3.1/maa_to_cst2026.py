#!/usr/bin/env python3
"""MMANA .MAA to CST Studio Suite 2026 VBA macro generator.
Conservative beta: geometry reliable by parsing, ports only safe center cases, loads audited.
"""
from __future__ import annotations
import argparse,csv,json,math,re,sys
from pathlib import Path

VERSION='0.3.1-DUAL-EXPORT'
TOKEN=re.compile(r'^w(\d+)([bce])([+-]\d+)?$',re.I)
def parse_file(path):
    data=Path(path).read_bytes()
    text=None
    for enc in ('utf-8-sig','cp1251','latin1'):
        try: text=data.decode(enc);break
        except UnicodeDecodeError: continue
    lines=[l.strip() for l in text.replace('\r','\n').split('\n') if l.strip()]
    def label(line):
        raw=line.strip().strip('*').strip().lower().replace(' ','').replace('.','')
        if raw in ('wires','провода','проводники'):return 'wires'
        if raw in ('source','источ','источник','источники'):return 'source'
        if raw in ('load','нагрузка','нагрузки'):return 'load'
        return None
    headers={}
    for i,l in enumerate(lines):
        k=label(l)
        if k and k not in headers:headers[k]=i
    if 'wires' not in headers:raise ValueError('No recognized wires section (*Wires* / *Провода*)')
    idx=headers['wires']
    try:freq=float(lines[idx-1].replace(',','.'))
    except Exception:raise ValueError('Invalid frequency before wires section')
    if not math.isfinite(freq) or not 0<freq<1e6:raise ValueError('Invalid frequency')
    header_fields=[v.strip() for v in lines[idx+1].split(',')]
    n=int(float(header_fields[0]))
    # MMANA wire header: base wires, horizontal copies, vertical copies,
    # horizontal spacing in meters, vertical spacing in meters, position mode.
    # The $$$Taper wire set$$$ / Russian combined-wire section is unrelated.
    try:
        nh=int(float(header_fields[1])) if len(header_fields)>1 else 1
        nv=int(float(header_fields[2])) if len(header_fields)>2 else 1
        dh=float(header_fields[3]) if len(header_fields)>3 else 0.0
        dv=float(header_fields[4]) if len(header_fields)>4 else 0.0
        placement=int(float(header_fields[5])) if len(header_fields)>5 else 0
        if not (1<=nh<=8 and 1<=nv<=8 and nh*nv<=64):raise ValueError('invalid MMANA stack copies')
        if not all(math.isfinite(v) for v in (dh,dv)):raise ValueError('invalid stack spacing')
    except (ValueError,IndexError) as ex:
        raise ValueError('Invalid MAA stack wire header: '+str(ex))
    warnings=[];wires=[];signed_radius_wires=[]
    for j in range(n):
        try:
            ln=lines[idx+2+j];x=[v.strip() for v in ln.split(',')]
            if len(x)<8:raise ValueError('too few columns')
            vals=[float(t) for t in x[:7]];seg=int(float(x[7]));a=tuple(vals[:3]);b=tuple(vals[3:6]);r=vals[6]
            if not all(math.isfinite(v) for v in vals):raise ValueError('nonfinite coordinate or radius')
            if math.dist(a,b)<1e-10:raise ValueError('zero-length wire')
            if abs(r)<1e-12:raise ValueError('zero radius — not substituted')
            if r<0:
                signed_radius_wires.append(j+1)
                warnings.append(f'Wire {j+1}: signed radius {r:g} denotes combined/tapered wire; exact diameter profile NOT IMPLEMENTED, refuse inaccurate solid Wire')
            wires.append({'a':a,'b':b,'r':abs(r),'seg':seg,'signed_radius':r})
        except Exception as ex:
            warnings.append(f'Wire {j+1}: NOT EXPORTED: {ex}')
            wires.append(None)
    def records(section):
        k=headers.get(section)
        if k is None:return []
        try:count=int(float(lines[k+1].split(',')[0].strip()))
        except Exception:
            warnings.append(f'{section}: invalid record count');return []
        result=[]
        for j in range(count):
            try:result.append([x.strip() for x in lines[k+2+j].split(',')])
            except Exception as ex:warnings.append(f'{section} record {j+1}: {ex}')
        return result
    sources=records('source');loads=records('load');base_count=len(wires)
    stack={'horizontal':nh,'vertical':nv,'horizontal_spacing_m':dh,'vertical_spacing_m':dv,'placement_mode':placement,'copies':nh*nv,'base_wires':base_count,'expanded':nh*nv>1}
    if nh*nv>1:
        # Horizontal array separation is Y; vertical array separation is Z.
        # Position mode 0 is the centered layout used in the supplied stack cases.
        # Other position codes must be independently confirmed in MMANA.
        if placement not in (0,):
            warnings.append(f'Stack placement mode {placement}: assumed centered; verify against MMANA View')
        new_wires=[];new_sources=[];new_loads=[]
        for vz in range(nv):
            for hy in range(nh):
                dy=(hy-(nh-1)/2)*dh;dz=(vz-(nv-1)/2)*dv
                offset=len(new_wires)
                for w in wires:
                    if w is None:new_wires.append(None);continue
                    nw=dict(w)
                    nw['a']=(w['a'][0],w['a'][1]+dy,w['a'][2]+dz)
                    nw['b']=(w['b'][0],w['b'][1]+dy,w['b'][2]+dz)
                    new_wires.append(nw)
                for rec in sources:
                    copy=list(rec)
                    m=TOKEN.fullmatch(copy[0].lower().replace(' ','')) if copy else None
                    if m:
                        copy[0]='w'+str(int(m[1])+offset)+m[2]+(m[3] or '')
                        if len(copy)>2:
                            try:copy[2]=str(float(copy[2])/(nh*nv))
                            except ValueError:warnings.append('Stack source amplitude not numeric: '+str(copy))
                    else:warnings.append('Unresolved stack source: '+str(copy))
                    new_sources.append(copy)
                for rec in loads:
                    copy=list(rec)
                    m=TOKEN.fullmatch(copy[0].lower().replace(' ','')) if copy else None
                    if m:copy[0]='w'+str(int(m[1])+offset)+m[2]+(m[3] or '')
                    else:warnings.append('Unresolved stack load: '+str(copy))
                    new_loads.append(copy)
        wires,sources,loads=new_wires,new_sources,new_loads
    return {'name':lines[0] if idx>2 else Path(path).stem,'freq':freq,'wires':wires,'sources':sources,'loads':loads,'path':str(path),'parse_warnings':warnings,'stack':stack,'has_combined_wires':bool(signed_radius_wires)}

def position(w, tag, frequency_mhz=145.0):
    m=TOKEN.fullmatch(tag.lower().replace(' ',''))
    if not m:return None,'bad pulse token'
    idx=int(m[1])-1
    if not (0<=idx<len(w)):return None,'wire number out of range'
    if w[idx] is None:return None,'source/load references a non-exportable wire'
    wire=w[idx];seg=wire['seg'];where=m[2];offset=int(m[3] or 0)
    if offset:
        return None,'indexed pulse offsets require MMANA segmentation reconstruction'
    if where=='c':return (idx,0.5),'center pulse'
    length=math.dist(wire['a'],wire['b'])
    if seg>0:
        t=0.5/seg if where=='b' else 1-0.5/seg
        return (idx,t),'end pulse midpoint, explicit equal segmentation (verify MMANA method)'
    # Conservative geometry approximation; NOT claimed as exact MMANA pulse position.
    wavelength=299.792458/frequency_mhz
    first_seg=min(length/7.0,wavelength/40.0)
    t=(first_seg/2.0)/length
    return (idx,t if where=='b' else 1-t),'APPROXIMATE auto-segmented endpoint; compare with MMANA pulse position'

def xyz(w,t):return tuple((1-t)*a+t*b for a,b in zip(w['a'],w['b']))
def num(v):return f'{v:.10g}'
def vq(v):return ', '.join('"'+num(x)+'"' for x in v)
def emit(model, port_gap_ratio=0.4, port_impedance=50, sweep_percent=5.0):
    """Strict geometry-only export. Never introduce electrical cuts, ports or loads."""
    if not math.isfinite(sweep_percent) or not (0 < sweep_percent < 100):
        raise ValueError("Sweep percent must be > 0 and < 100")
    center_ghz=model['freq']/1000.0
    fmin=center_ghz*(1-sweep_percent/100)
    fmax=center_ghz*(1+sweep_percent/100)
    wires=model['wires']
    if model.get('has_combined_wires'):
        raise ValueError('Exact geometry unavailable: MAA signed radii/combined stepped wires require profile reconstruction. Refusing inaccurate constant-radius export.')
    warnings=list(model.get('parse_warnings',[]))
    stack=model.get('stack',{})
    if stack.get('placement_mode',0)!=0:
        warnings.append('Unverified placement mode: exact stack geometry NOT guaranteed')
    if any(w is None for w in wires):
        warnings.append('Some input wires could not be exported; inspect omitted_wire_indices')
    lines=[
        "' MAA -> CST Studio Suite 2026 | UA1CFM | 2026",
        "' GEOMETRY ONLY; NO PORTS / NO LOADS / NO CUTS / NO ADJUSTMENTS",
        f"' Generator version {VERSION}",
        "' Source: "+Path(model['path']).name,
        f"' MMANA frequency: {num(model['freq'])} MHz",
        f"' Frequency sweep: {num(fmin*1000)} to {num(fmax*1000)} MHz",
        "' Original MAA wire endpoints are preserved (meters -> millimeters).",
        "' Manual CST mesh settings; existing project geometry is NOT deleted.",
        'Sub Main()',
        '    With Units',
        '        .Geometry "mm"',
        '        .Frequency "GHz"',
        '    End With',
        '    Solver.FrequencyRange "'+num(fmin)+'", "'+num(fmax)+'"',
        '',
        '    With FDSolver',
        '        .Reset',
        '        .SetMethod "Surface", "General purpose"',
        '        .OrderSrf "First"',
        '        .Stimulation "All", "All"',
        '        .SweepMinimumSamples "10"',
        '        .SetNumberOfResultDataSamples "1001"',
        '        .SetResultDataSamplingMode "Automatic"',
        '        .AddSampleInterval "'+num(fmin)+'", "'+num(fmax)+'", "25", "Automatic", "False"',
        '        .AddSampleInterval "'+num(center_ghz)+'", "'+num(center_ghz)+'", "1", "Single", "False"',
        '    End With',''
    ]
    for i,w in enumerate(wires,1):
        if w is None:continue
        name=f'W{i:04d}'
        lines += [
            f"    ' Wire {i}: complete, unmodified MAA endpoints",
            '    With Polygon3D','        .Reset','        .Version 10',
            f'        .Name "poly_{name}"','        .Curve "MAA_Curves"',
            f'        .Point {vq(tuple(x*1000 for x in w["a"]))}',
            f'        .Point {vq(tuple(x*1000 for x in w["b"]))}',
            '        .Create','    End With','',
            '    With Wire','        .Reset',f'        .Name "wire_{name}"',
            '        .Folder "MAA_Curves"',
            f'        .Radius "{num(w["r"]*1000)}"',
            '        .Type "CurveWire"',f'        .Curve "MAA_Curves:poly_{name}"',
            '        .Material "PEC"','        .SolidWireModel "False"',
            '        .Termination "Natural"','        .Mitering "NewMiter"',
            '        .AdvancedChainSelection "True"','        .Add','    End With',''
        ]
    count=sum(w is not None for w in wires)
    lines += [f'    MsgBox "Created {count} complete Wire objects (geometry only). No ports, loads or cuts.", vbInformation, "MAA to CST Geometry Only"', 'End Sub','']
    audit={
        'version':VERSION,'input':model['path'],'name':model['name'],
        'geometry_only':True,'wire_count':len(wires),'wire_exported_count':count,
        'omitted_wire_indices':[i for i,w in enumerate(wires,1) if w is None],
        'all_original_endpoints_preserved':all(w is not None for w in wires),
        'coordinate_transform':'only m -> mm, plus MMANA stack replication if specified',
        'source_count_in_maa':len(model['sources']),'load_count_in_maa':len(model['loads']),
        'ports_exported':0,'loads_exported':0,'wires_cut':0,
        'stack':stack,'parse_warnings':warnings,
        'stack_placement_unverified':stack.get('placement_mode',0)!=0,
        'geometry_exactness_not_verified_for_combined_taper_wires':False,
        'wire_details':[{'index':i,'a_m':w['a'],'b_m':w['b'],'radius_m':w['r'],'seg':w['seg']} for i,w in enumerate(wires,1) if w is not None],
        'frequency_mhz':model['freq'],'sweep_start_mhz':fmin*1000,'sweep_stop_mhz':fmax*1000,
        'mesh':'manual; no Mesh commands generated',
        'geometry_warning':'Stepped/tapered combined-wire sections are not yet reconstructed from their detailed profile. An exported BAS is NOT proof of complete exact geometry.'
    }
    return '\n'.join(lines), audit

def fairbeam_design(model, audit, relative, sweep_percent=5.0):
    """Geometry-only Fairbeam schema design/1, using the very same parsed wires as BAS."""
    import hashlib
    wires=model['wires']
    if model.get('has_combined_wires') or any(w is None for w in wires):
        raise ValueError('Incomplete geometry: Fairbeam file withheld rather than substituting wires')
    f=model['freq']/1000
    primitives=[]
    for w in wires:
        primitives.append({'kind':'wire',
                           'points':[[round(v*1000,9) for v in w['a']],
                                     [round(v*1000,9) for v in w['b']]],
                           'radius':round(w['r']*1000,9)})
    if not all(p['radius']>0 and len(p['points'])==2 and all(math.isfinite(x) for pt in p['points'] for x in pt) for p in primitives):
        raise ValueError('Invalid wire geometry, Fairbeam export refused')
    # The minimal Fairbeam v1 design schema comes from the previously validated
    # MAA-to-Fairbeam v1.2.2 projects. No custom diagnostic data in this JSON.
    return {
       'schema':'fairbeam.design/1',
       'model':{'id':'maa_'+__import__('hashlib').sha1(str(relative).encode('utf-8','surrogateescape')).hexdigest()[:12],
                'name':model['name'].encode('utf-8','replace').decode('utf-8')},
       'params':[],
       'simulation':{'f_min':round(f*(1-sweep_percent/100),12),
                     'f_max':round(f*(1+sweep_percent/100),12),
                     'boundaries':'MUR','end_criteria_db':-40},
       'materials':[{'name':'copper','kind':'metal'}],
       'parts':[{'name':'antenna','material':'copper','primitives':primitives}],
       'ports':[], 'resistors':[],
       'mesh':{'mode':'auto','cells_per_wavelength':20},
       'far_field':{'enabled':True,'frequencies':[round(f,12)]},
    }

def audit_to_text(audit, src, formats, extra=None):
    lines=['MAA → CST / Fairbeam | UA1CFM © 2026',
           'Converter '+VERSION,'Source: '+str(src),
           'Output formats: '+', '.join(formats),
           'Status: geometry only (NO PORTS; NO LOADS)',
           'Frequency MHz: '+str(audit.get('frequency_mhz')),
           'Frequency range MHz: '+str(audit.get('sweep_start_mhz'))+' .. '+str(audit.get('sweep_stop_mhz')),
           'Wires: '+str(audit.get('wire_exported_count'))+' / '+str(audit.get('wire_count')),
           'Original MAA sources (not exported): '+str(audit.get('source_count_in_maa')),
           'Original MAA loads (not exported): '+str(audit.get('load_count_in_maa')),
           'Stack: '+str(audit.get('stack')),
           'NOT a guarantee of identical MMANA radiation/impedance.',
           'Warnings:']
    lines.extend(' - '+str(x) for x in audit.get('parse_warnings',[]))
    if not audit.get('parse_warnings'):lines.append(' - none')
    if extra:lines.extend(['Other diagnostics:']+[' - '+str(x) for x in extra])
    lines.append('')
    return '\n'.join(lines)

def convert_file(src,dest,sweep_percent=5.0,output_formats=('cst','fairbeam'),report_root=None,relative=None):
    src=Path(src);dest=Path(dest)
    selected=set(output_formats)
    if not selected or selected-{'cst','fairbeam'}:raise ValueError('Choose cst, fairbeam or both')
    model=parse_file(src)
    model['path']=model['path'].encode('utf-8','replace').decode('utf-8')
    model['name']=model['name'].encode('utf-8','replace').decode('utf-8')
    macro,audit=emit(model,sweep_percent=sweep_percent)
    relative=Path(relative) if relative is not None else Path(src.name)
    created=[]
    if 'fairbeam' in selected:
        design=fairbeam_design(model,audit,relative,sweep_percent)
        # Validate before writing anything. The schema is the established Fairbeam design/1.
        if design['schema']!='fairbeam.design/1' or not design['parts'][0]['primitives']:
            raise ValueError('Fairbeam schema/geometry failed validation')
        target=dest.with_suffix('.design.json')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(json.dumps(design,ensure_ascii=False,indent=2),encoding='utf-8')
        created.append(str(target))
    if 'cst' in selected:
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(macro,encoding='utf-8-sig')
        created.append(str(dest))
    if report_root is None:report_root=dest.parent/'reports'
    report=Path(report_root)/relative.with_suffix('.txt')
    report.parent.mkdir(parents=True,exist_ok=True)
    report.write_text(audit_to_text(audit,src,sorted(selected)),encoding='utf-8',errors='replace')
    audit['created_files']=created
    audit['report_txt']=str(report)
    return audit

def batch(root,out,sweep_percent=5.0,progress=None,output_formats=('cst','fairbeam')):
    root=Path(root);out=Path(out)
    items=sorted((p for p in root.rglob('*') if p.is_file() and p.suffix.lower()=='.maa'),key=lambda p:str(p).casefold())
    out.mkdir(exist_ok=True,parents=True)
    rows=[]
    if progress:progress(0,len(items),None)
    for p in items:
        rel=p.relative_to(root);dst=out/rel.with_suffix('.bas')
        entry={'file':str(rel),'bas':str(dst.relative_to(out)) if 'cst' in output_formats else '',
               'fairbeam':str(rel.with_suffix('.design.json')) if 'fairbeam' in output_formats else ''}
        try:
            audit=convert_file(p,dst,sweep_percent,output_formats,out/'reports',rel)
            entry.update({'status':'OK' if not audit['parse_warnings'] else 'WARNINGS',
                          'wires':audit['wire_count'],'exported_wires':audit['wire_exported_count'],
                          'sources':audit['source_count_in_maa'],'ports':0,
                          'loads':audit['load_count_in_maa'],'exported_loads':0,
                          'issue_count':len(audit['parse_warnings']),
                          'frequency_mhz':audit['frequency_mhz'],
                          'sweep_start_mhz':audit['sweep_start_mhz'],
                          'sweep_stop_mhz':audit['sweep_stop_mhz']})
        except Exception as e:
            # No fabricated BAS or JSON for unsupported exact geometry.
            error=str(e);entry.update({'status':'ERROR','error':error})
            report=(out/'reports'/rel.with_suffix('.txt'))
            report.parent.mkdir(exist_ok=True,parents=True)
            report.write_text('MAA conversion FAILED\nSource: '+str(p)+'\nReason: '+error+'\nNo valid design emitted.\n',encoding='utf-8',errors='replace')
        rows.append(entry)
        if progress:progress(len(rows),len(items),entry)
    fieldnames=['file','bas','fairbeam','status','wires','exported_wires','sources','ports','loads','exported_loads','issue_count','frequency_mhz','sweep_start_mhz','sweep_stop_mhz','error']
    with (out/'BATCH_REPORT.csv').open('w',newline='',encoding='utf-8-sig',errors='replace') as f:
        writer=csv.DictWriter(f,fieldnames=fieldnames);writer.writeheader();writer.writerows(rows)
    with (out/'FAILED_AND_WARNINGS.txt').open('w',encoding='utf-8',errors='replace') as f:
        for r in rows:
            if r['status']!='OK':f.write(r['status']+' | '+r['file']+' | '+r.get('error',f"{r.get('issue_count',0)} warning(s)")+'\n')
    return rows

def gui():
    import tkinter as tk
    from tkinter import filedialog,messagebox,ttk
    import threading,queue
    win=tk.Tk();win.title('MAA → CST Studio Suite 2026 | UA1CFM 2026 | v'+VERSION);win.geometry('850x455')
    tk.Label(win,text='MMANA .MAA → CST BAS / Fairbeam JSON | ТОЛЬКО ГЕОМЕТРИЯ',font=('Segoe UI',16,'bold')).pack(pady=12)
    source=tk.StringVar();output=tk.StringVar();mode=tk.StringVar(value='folder');sweep_var=tk.StringVar(value='5')
    info=tk.StringVar(value='Выберите MAA, формат(ы) и нажмите «НАЧАТЬ КОНВЕРТАЦИЮ»')
    cst_var=tk.BooleanVar(value=True);fairbeam_var=tk.BooleanVar(value=True)
    stats=tk.StringVar(value='Ожидание');pct=tk.StringVar(value='0%')
    frm=tk.Frame(win);frm.pack(fill='x',padx=15)
    def browse_src():
        if mode.get()=='folder':sel=filedialog.askdirectory(title='Выберите папку с MAA')
        else:sel=filedialog.askopenfilename(filetypes=[('MMANA antenna','*.maa'),('All files','*.*')])
        if sel:source.set(sel)
    def browse_out():
        sel=filedialog.askdirectory(title='Выберите папку для BAS')
        if sel:output.set(sel)
    choices=tk.Frame(frm);choices.pack(anchor='w')
    tk.Radiobutton(choices,text='Папка MAA (включая подпапки)',variable=mode,value='folder').pack(side='left')
    tk.Radiobutton(choices,text='Один файл MAA',variable=mode,value='file').pack(side='left',padx=20)
    for label,var,func in [('Вход:',source,browse_src),('Выход:',output,browse_out)]:
        row=tk.Frame(frm);row.pack(fill='x',pady=5)
        tk.Label(row,text=label,width=8,anchor='w').pack(side='left')
        tk.Entry(row,textvariable=var).pack(side='left',fill='x',expand=True)
        tk.Button(row,text='Обзор...',command=func,width=12).pack(side='left',padx=6)
    fmt=tk.Frame(frm);fmt.pack(anchor='w',pady=4)
    tk.Label(fmt,text='Экспорт:').pack(side='left')
    tk.Checkbutton(fmt,text='CST .bas',variable=cst_var).pack(side='left',padx=12)
    tk.Checkbutton(fmt,text='Fairbeam .design.json',variable=fairbeam_var).pack(side='left',padx=12)
    row=tk.Frame(frm);row.pack(anchor='w',pady=7)
    tk.Label(row,text='Sweep ± (%)').pack(side='left');tk.Entry(row,textvariable=sweep_var,width=9).pack(side='left',padx=10)
    bar=ttk.Progressbar(win,maximum=100,mode='determinate',length=720);bar.pack(pady=(13,4))
    tk.Label(win,textvariable=pct,font=('Segoe UI',12,'bold')).pack()
    tk.Label(win,textvariable=stats).pack(pady=3)
    tk.Label(win,textvariable=info,wraplength=740).pack(pady=3)
    events=queue.Queue();start_btn=None
    def poll():
        try:
            while True:
                typ,obj=events.get_nowait()
                if typ=='progress':
                    done,total,row=obj;percentage=100*done/total if total else 100
                    bar['value']=percentage;pct.set(f'{percentage:.1f}% ({done}/{total})')
                    if row:info.set(row['file']+' — '+row['status'])
                elif typ=='done':
                    start_btn.config(state='normal');stats.set(obj);info.set('Отчёты: reports/*.txt, BATCH_REPORT.csv и FAILED_AND_WARNINGS.txt')
                elif typ=='error':
                    start_btn.config(state='normal');info.set(obj);messagebox.showerror('Ошибка',obj)
        except queue.Empty:pass
        win.after(80,poll)
    def start():
        src=Path(source.get());dst=Path(output.get());
        if not src.exists() or not output.get():messagebox.showerror('Ошибка','Укажи существующий вход и папку результата');return
        try:
            sw=float(sweep_var.get().replace(',','.'))
            if not 0<sw<100:raise ValueError('Sweep должен быть между 0 и 100')
        except ValueError as exc:messagebox.showerror('Ошибка',str(exc));return
        selected_mode=mode.get()
        formats=tuple(x for x,on in (('cst',cst_var.get()),('fairbeam',fairbeam_var.get())) if on)
        if not formats:messagebox.showerror('Ошибка','Выбери хотя бы один формат');return
        start_btn.config(state='disabled');bar['value']=0;pct.set('0%');info.set('Конвертация...')
        def worker():
            try:
                if selected_mode=='folder':
                    rows=batch(src,dst,sw,lambda d,t,e:events.put(('progress',(d,t,e))),formats)
                    ok=sum(r['status']=='OK' for r in rows);warnings=sum(r['status']=='WARNINGS' for r in rows);errors=sum(r['status']=='ERROR' for r in rows)
                    events.put(('done',f'Всего {len(rows)} | без замечаний {ok} | с предупреждениями {warnings} | ошибок {errors}'))
                else:
                    result=convert_file(src,dst/(src.stem+'.bas'),sw,formats,dst/'reports')
                    events.put(('progress',(1,1,{'file':src.name,'status':'OK'})))
                    events.put(('done',f'Готово: {len(result["created_files"])} файлов | проводников {result["wire_exported_count"]} | замечаний {len(result["parse_warnings"])}'))
            except Exception as ex:events.put(('error',str(ex)))
        threading.Thread(target=worker,daemon=True).start()
    start_btn=tk.Button(win,text='▶ НАЧАТЬ КОНВЕРТАЦИЮ',font=('Segoe UI',12,'bold'),width=32,command=start)
    start_btn.pack(pady=10)
    tk.Label(win,text='© UA1CFM 2026 | Только геометрия, без портов и нагрузок | Mesh вручную',fg='gray').pack()
    win.after(80,poll);win.mainloop()

def main():
    ap=argparse.ArgumentParser(description='MAA → CST Studio 2026 VBA .bas generator')
    ap.add_argument('--input',help='Single MAA file');ap.add_argument('--output',help='Output BAS filename for single-file conversion');ap.add_argument('--sweep-percent',type=float,default=5.0,help='Half-width of frequency sweep in percent (default: 5)');ap.add_argument('--format',choices=['cst','fairbeam','both'],default='both',help='Output format')
    ap.add_argument('--batch',help='MAA input folder');ap.add_argument('--outdir',help='Output folder');a=ap.parse_args()
    formats=('cst','fairbeam') if a.format=='both' else (a.format,)
    if a.batch:print('Processed',len(batch(a.batch,a.outdir or 'Converted',a.sweep_percent,output_formats=formats)),'files')
    elif a.input:
        outbase=Path(a.output) if a.output else (Path(a.outdir)/Path(a.input).with_suffix('.bas').name if a.outdir else Path(a.input).with_suffix('.bas'))
        print(json.dumps(convert_file(a.input,outbase,a.sweep_percent,formats),ensure_ascii=True,indent=2))
    else:gui()
if __name__=='__main__':main()
