﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' GEOMETRY ONLY; NO PORTS / NO LOADS / NO CUTS / NO ADJUSTMENTS
' Generator version 0.3.0-GEOMETRY-ONLY
' Source: 4xQQ.maa
' MMANA frequency: 14.05 MHz
' Frequency sweep: 13.3475 to 14.7525 MHz
' Original MAA wire endpoints are preserved (meters -> millimeters).
' Manual CST mesh settings; existing project geometry is NOT deleted.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.0133475", "0.0147525"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.0133475", "0.0147525", "25", "Automatic", "False"
        .AddSampleInterval "0.01405", "0.01405", "1", "Single", "False"
    End With

    ' Wire 1: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001"
        .Curve "MAA_Curves"
        .Point "0", "-8015.0195", "-8015.0195"
        .Point "0", "-2654.0195", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 2: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "0", "-2654.0195", "-8015.0195"
        .Point "0", "-2654.0195", "-2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 3: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "0", "-2654.0195", "-2654.0195"
        .Point "0", "-8015.0195", "-2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 4: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "0", "-8015.0195", "-2654.0195"
        .Point "0", "-8015.0195", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 5: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "-2590", "-8133.2695", "-8133.2695"
        .Point "-2590", "-2535.7695", "-8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 6: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "-2590", "-2535.7695", "-8133.2695"
        .Point "-2590", "-2535.7695", "-2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 7: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "-2590", "-2535.7695", "-2535.7695"
        .Point "-2590", "-8133.2695", "-2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 8: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "-2590", "-8133.2695", "-2535.7695"
        .Point "-2590", "-8133.2695", "-8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 9: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009"
        .Curve "MAA_Curves"
        .Point "0", "2654.0195", "-8015.0195"
        .Point "0", "8015.0195", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 10: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010"
        .Curve "MAA_Curves"
        .Point "0", "8015.0195", "-8015.0195"
        .Point "0", "8015.0195", "-2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 11: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "0", "8015.0195", "-2654.0195"
        .Point "0", "2654.0195", "-2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 12: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "0", "2654.0195", "-2654.0195"
        .Point "0", "2654.0195", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 13: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013"
        .Curve "MAA_Curves"
        .Point "-2590", "2535.7695", "-8133.2695"
        .Point "-2590", "8133.2695", "-8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 14: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0014"
        .Curve "MAA_Curves"
        .Point "-2590", "8133.2695", "-8133.2695"
        .Point "-2590", "8133.2695", "-2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0014"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0014"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 15: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0015"
        .Curve "MAA_Curves"
        .Point "-2590", "8133.2695", "-2535.7695"
        .Point "-2590", "2535.7695", "-2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0015"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0015"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 16: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0016"
        .Curve "MAA_Curves"
        .Point "-2590", "2535.7695", "-2535.7695"
        .Point "-2590", "2535.7695", "-8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0016"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0016"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 17: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0017"
        .Curve "MAA_Curves"
        .Point "0", "-8015.0195", "2654.0195"
        .Point "0", "-2654.0195", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0017"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0017"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 18: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0018"
        .Curve "MAA_Curves"
        .Point "0", "-2654.0195", "2654.0195"
        .Point "0", "-2654.0195", "8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0018"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0018"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 19: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0019"
        .Curve "MAA_Curves"
        .Point "0", "-2654.0195", "8015.0195"
        .Point "0", "-8015.0195", "8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0019"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0019"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 20: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0020"
        .Curve "MAA_Curves"
        .Point "0", "-8015.0195", "8015.0195"
        .Point "0", "-8015.0195", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0020"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0020"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 21: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0021"
        .Curve "MAA_Curves"
        .Point "-2590", "-8133.2695", "2535.7695"
        .Point "-2590", "-2535.7695", "2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0021"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0021"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 22: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0022"
        .Curve "MAA_Curves"
        .Point "-2590", "-2535.7695", "2535.7695"
        .Point "-2590", "-2535.7695", "8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0022"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0022"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 23: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0023"
        .Curve "MAA_Curves"
        .Point "-2590", "-2535.7695", "8133.2695"
        .Point "-2590", "-8133.2695", "8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0023"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0023"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 24: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0024"
        .Curve "MAA_Curves"
        .Point "-2590", "-8133.2695", "8133.2695"
        .Point "-2590", "-8133.2695", "2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0024"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0024"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 25: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0025"
        .Curve "MAA_Curves"
        .Point "0", "2654.0195", "2654.0195"
        .Point "0", "8015.0195", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0025"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0025"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 26: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0026"
        .Curve "MAA_Curves"
        .Point "0", "8015.0195", "2654.0195"
        .Point "0", "8015.0195", "8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0026"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0026"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 27: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0027"
        .Curve "MAA_Curves"
        .Point "0", "8015.0195", "8015.0195"
        .Point "0", "2654.0195", "8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0027"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0027"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 28: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0028"
        .Curve "MAA_Curves"
        .Point "0", "2654.0195", "8015.0195"
        .Point "0", "2654.0195", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0028"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0028"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 29: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0029"
        .Curve "MAA_Curves"
        .Point "-2590", "2535.7695", "2535.7695"
        .Point "-2590", "8133.2695", "2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0029"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0029"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 30: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0030"
        .Curve "MAA_Curves"
        .Point "-2590", "8133.2695", "2535.7695"
        .Point "-2590", "8133.2695", "8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0030"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0030"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 31: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0031"
        .Curve "MAA_Curves"
        .Point "-2590", "8133.2695", "8133.2695"
        .Point "-2590", "2535.7695", "8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0031"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0031"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 32: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0032"
        .Curve "MAA_Curves"
        .Point "-2590", "2535.7695", "8133.2695"
        .Point "-2590", "2535.7695", "2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0032"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0032"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    MsgBox "Created 32 complete Wire objects (geometry only). No ports, loads or cuts.", vbInformation, "MAA to CST Geometry Only"
End Sub
