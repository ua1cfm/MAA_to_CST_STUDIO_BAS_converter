﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' GEOMETRY ONLY; NO PORTS / NO LOADS / NO CUTS / NO ADJUSTMENTS
' Generator version 0.3.0-GEOMETRY-ONLY
' Source: 4X12.MAA
' MMANA frequency: 435 MHz
' Frequency sweep: 413.25 to 456.75 MHz
' Original MAA wire endpoints are preserved (meters -> millimeters).
' Manual CST mesh settings; existing project geometry is NOT deleted.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.41325", "0.45675"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.41325", "0.45675", "25", "Automatic", "False"
        .AddSampleInterval "0.435", "0.435", "1", "Single", "False"
    End With

    ' Wire 1: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001"
        .Curve "MAA_Curves"
        .Point "0", "-1033.7925", "-154"
        .Point "0", "-1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 2: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "-110", "-1033.7925", "-175"
        .Point "-110", "-1033.7925", "175"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 3: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "70", "-1033.7925", "-147.5"
        .Point "70", "-1033.7925", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 4: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "150", "-1033.7925", "-147.5"
        .Point "150", "-1033.7925", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 5: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "240", "-1033.7925", "-145"
        .Point "240", "-1033.7925", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 6: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "360", "-1033.7925", "-145"
        .Point "360", "-1033.7925", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 7: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "500", "-1033.7925", "-140"
        .Point "500", "-1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 8: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "650", "-1033.7925", "-140"
        .Point "650", "-1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 9: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009"
        .Curve "MAA_Curves"
        .Point "820", "-1033.7925", "-140"
        .Point "820", "-1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 10: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010"
        .Curve "MAA_Curves"
        .Point "990", "-1033.7925", "-140"
        .Point "990", "-1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 11: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "1150", "-1033.7925", "-135"
        .Point "1150", "-1033.7925", "135"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 12: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "1350", "-1033.7925", "-130"
        .Point "1350", "-1033.7925", "130"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 13: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013"
        .Curve "MAA_Curves"
        .Point "-10", "-1033.7925", "0"
        .Point "-10", "-1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 14: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0014"
        .Curve "MAA_Curves"
        .Point "0", "-1033.7925", "0"
        .Point "0", "-1033.7925", "154"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0014"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0014"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 15: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0015"
        .Curve "MAA_Curves"
        .Point "0", "-1033.7925", "-68"
        .Point "0", "-1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0015"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0015"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 16: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0016"
        .Curve "MAA_Curves"
        .Point "-10", "-1033.7925", "-68"
        .Point "0", "-1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0016"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0016"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 17: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0017"
        .Curve "MAA_Curves"
        .Point "-10", "-1033.7925", "0"
        .Point "0", "-1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0017"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0017"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 18: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0018"
        .Curve "MAA_Curves"
        .Point "0", "-344.5975", "-154"
        .Point "0", "-344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0018"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0018"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 19: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0019"
        .Curve "MAA_Curves"
        .Point "-110", "-344.5975", "-175"
        .Point "-110", "-344.5975", "175"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0019"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0019"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 20: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0020"
        .Curve "MAA_Curves"
        .Point "70", "-344.5975", "-147.5"
        .Point "70", "-344.5975", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0020"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0020"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 21: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0021"
        .Curve "MAA_Curves"
        .Point "150", "-344.5975", "-147.5"
        .Point "150", "-344.5975", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0021"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0021"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 22: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0022"
        .Curve "MAA_Curves"
        .Point "240", "-344.5975", "-145"
        .Point "240", "-344.5975", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0022"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0022"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 23: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0023"
        .Curve "MAA_Curves"
        .Point "360", "-344.5975", "-145"
        .Point "360", "-344.5975", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0023"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0023"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 24: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0024"
        .Curve "MAA_Curves"
        .Point "500", "-344.5975", "-140"
        .Point "500", "-344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0024"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0024"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 25: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0025"
        .Curve "MAA_Curves"
        .Point "650", "-344.5975", "-140"
        .Point "650", "-344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0025"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0025"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 26: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0026"
        .Curve "MAA_Curves"
        .Point "820", "-344.5975", "-140"
        .Point "820", "-344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0026"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0026"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 27: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0027"
        .Curve "MAA_Curves"
        .Point "990", "-344.5975", "-140"
        .Point "990", "-344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0027"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0027"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 28: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0028"
        .Curve "MAA_Curves"
        .Point "1150", "-344.5975", "-135"
        .Point "1150", "-344.5975", "135"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0028"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0028"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 29: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0029"
        .Curve "MAA_Curves"
        .Point "1350", "-344.5975", "-130"
        .Point "1350", "-344.5975", "130"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0029"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0029"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 30: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0030"
        .Curve "MAA_Curves"
        .Point "-10", "-344.5975", "0"
        .Point "-10", "-344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0030"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0030"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 31: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0031"
        .Curve "MAA_Curves"
        .Point "0", "-344.5975", "0"
        .Point "0", "-344.5975", "154"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0031"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0031"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 32: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0032"
        .Curve "MAA_Curves"
        .Point "0", "-344.5975", "-68"
        .Point "0", "-344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0032"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0032"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 33: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0033"
        .Curve "MAA_Curves"
        .Point "-10", "-344.5975", "-68"
        .Point "0", "-344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0033"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0033"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 34: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0034"
        .Curve "MAA_Curves"
        .Point "-10", "-344.5975", "0"
        .Point "0", "-344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0034"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0034"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 35: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0035"
        .Curve "MAA_Curves"
        .Point "0", "344.5975", "-154"
        .Point "0", "344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0035"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0035"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 36: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0036"
        .Curve "MAA_Curves"
        .Point "-110", "344.5975", "-175"
        .Point "-110", "344.5975", "175"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0036"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0036"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 37: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0037"
        .Curve "MAA_Curves"
        .Point "70", "344.5975", "-147.5"
        .Point "70", "344.5975", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0037"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0037"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 38: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0038"
        .Curve "MAA_Curves"
        .Point "150", "344.5975", "-147.5"
        .Point "150", "344.5975", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0038"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0038"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 39: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0039"
        .Curve "MAA_Curves"
        .Point "240", "344.5975", "-145"
        .Point "240", "344.5975", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0039"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0039"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 40: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0040"
        .Curve "MAA_Curves"
        .Point "360", "344.5975", "-145"
        .Point "360", "344.5975", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0040"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0040"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 41: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0041"
        .Curve "MAA_Curves"
        .Point "500", "344.5975", "-140"
        .Point "500", "344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0041"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0041"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 42: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0042"
        .Curve "MAA_Curves"
        .Point "650", "344.5975", "-140"
        .Point "650", "344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0042"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0042"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 43: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0043"
        .Curve "MAA_Curves"
        .Point "820", "344.5975", "-140"
        .Point "820", "344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0043"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0043"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 44: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0044"
        .Curve "MAA_Curves"
        .Point "990", "344.5975", "-140"
        .Point "990", "344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0044"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0044"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 45: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0045"
        .Curve "MAA_Curves"
        .Point "1150", "344.5975", "-135"
        .Point "1150", "344.5975", "135"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0045"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0045"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 46: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0046"
        .Curve "MAA_Curves"
        .Point "1350", "344.5975", "-130"
        .Point "1350", "344.5975", "130"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0046"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0046"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 47: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0047"
        .Curve "MAA_Curves"
        .Point "-10", "344.5975", "0"
        .Point "-10", "344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0047"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0047"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 48: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0048"
        .Curve "MAA_Curves"
        .Point "0", "344.5975", "0"
        .Point "0", "344.5975", "154"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0048"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0048"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 49: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0049"
        .Curve "MAA_Curves"
        .Point "0", "344.5975", "-68"
        .Point "0", "344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0049"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0049"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 50: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0050"
        .Curve "MAA_Curves"
        .Point "-10", "344.5975", "-68"
        .Point "0", "344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0050"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0050"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 51: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0051"
        .Curve "MAA_Curves"
        .Point "-10", "344.5975", "0"
        .Point "0", "344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0051"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0051"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 52: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0052"
        .Curve "MAA_Curves"
        .Point "0", "1033.7925", "-154"
        .Point "0", "1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0052"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0052"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 53: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0053"
        .Curve "MAA_Curves"
        .Point "-110", "1033.7925", "-175"
        .Point "-110", "1033.7925", "175"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0053"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0053"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 54: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0054"
        .Curve "MAA_Curves"
        .Point "70", "1033.7925", "-147.5"
        .Point "70", "1033.7925", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0054"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0054"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 55: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0055"
        .Curve "MAA_Curves"
        .Point "150", "1033.7925", "-147.5"
        .Point "150", "1033.7925", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0055"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0055"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 56: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0056"
        .Curve "MAA_Curves"
        .Point "240", "1033.7925", "-145"
        .Point "240", "1033.7925", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0056"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0056"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 57: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0057"
        .Curve "MAA_Curves"
        .Point "360", "1033.7925", "-145"
        .Point "360", "1033.7925", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0057"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0057"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 58: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0058"
        .Curve "MAA_Curves"
        .Point "500", "1033.7925", "-140"
        .Point "500", "1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0058"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0058"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 59: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0059"
        .Curve "MAA_Curves"
        .Point "650", "1033.7925", "-140"
        .Point "650", "1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0059"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0059"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 60: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0060"
        .Curve "MAA_Curves"
        .Point "820", "1033.7925", "-140"
        .Point "820", "1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0060"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0060"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 61: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0061"
        .Curve "MAA_Curves"
        .Point "990", "1033.7925", "-140"
        .Point "990", "1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0061"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0061"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 62: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0062"
        .Curve "MAA_Curves"
        .Point "1150", "1033.7925", "-135"
        .Point "1150", "1033.7925", "135"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0062"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0062"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 63: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0063"
        .Curve "MAA_Curves"
        .Point "1350", "1033.7925", "-130"
        .Point "1350", "1033.7925", "130"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0063"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0063"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 64: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0064"
        .Curve "MAA_Curves"
        .Point "-10", "1033.7925", "0"
        .Point "-10", "1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0064"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0064"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 65: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0065"
        .Curve "MAA_Curves"
        .Point "0", "1033.7925", "0"
        .Point "0", "1033.7925", "154"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0065"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0065"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 66: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0066"
        .Curve "MAA_Curves"
        .Point "0", "1033.7925", "-68"
        .Point "0", "1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0066"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0066"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 67: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0067"
        .Curve "MAA_Curves"
        .Point "-10", "1033.7925", "-68"
        .Point "0", "1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0067"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0067"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    ' Wire 68: complete, unmodified MAA endpoints
    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0068"
        .Curve "MAA_Curves"
        .Point "-10", "1033.7925", "0"
        .Point "0", "1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0068"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0068"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    MsgBox "Created 68 complete Wire objects (geometry only). No ports, loads or cuts.", vbInformation, "MAA to CST Geometry Only"
End Sub
