import tempfile,unittest,sys,pathlib,json
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from maa_to_cst2026 import parse_file,emit,batch
ROOT=pathlib.Path('/mnt/data')
class Tests(unittest.TestCase):
 def test_twinloop_port(self):
  m=parse_file(ROOT/'TWINLOOP.MAA');t,a=emit(m)
  self.assertEqual((a['wire_count'],a['port_count']), (7,1))
  self.assertIn('With DiscretePort',t)
  self.assertIn('.Radius "5"',t)
 def test_bigstar_load_audit(self):
  m=parse_file(ROOT/'Big star(1).maa');_,a=emit(m)
  self.assertEqual(a['load_count'],2)
  self.assertEqual(len([i for i in a['issues'] if i['kind']=='load']),2)
 def test_qfh_wire_radii(self):
  m=parse_file(ROOT/'QFH 145__id216405.maa');t,a=emit(m)
  self.assertEqual(a['wire_count'],33)
  self.assertIn('.Radius "0.8"',t)
  self.assertIn('.Radius "3"',t)
  self.assertEqual(a['load_count'],2)
 def test_twind_cautious_port(self):
  m=parse_file(ROOT/'TWIND(1).MAA');_,a=emit(m)
  self.assertEqual(a['wire_count'],7)
  self.assertEqual(a['source_count'],1)
 def test_batch(self):
  with tempfile.TemporaryDirectory() as td:
   rows=batch(ROOT,td)
   self.assertGreaterEqual(len(rows),8)
   self.assertTrue((pathlib.Path(td)/'BATCH_REPORT.csv').exists())
if __name__=='__main__':unittest.main(verbosity=2)


class CST2026WireSyntaxTests(__import__('unittest').TestCase):
    def test_history_list_polygon_wire(self):
        from maa_to_cst2026 import parse_file, emit
        from pathlib import Path
        model=parse_file(Path(__file__).parent/'examples'/'TWINLOOP.MAA') if (Path(__file__).parent/'examples'/'TWINLOOP.MAA').exists() else None
        if model is None:
            import tempfile
            with tempfile.TemporaryDirectory() as td:
                p=Path(td)/'simple.MAA'
                p.write_text('simple\n435\n***Wires***\n1\n0,0,0,0.1,0.2,0.3,0.001,5\n***Source***\n0,0\n***Load***\n0,0\n',encoding='utf8')
                model=parse_file(p)
        macro,audit=emit(model)
        for required in ('With Polygon3D','.Version 10','.Point ','With Wire','.Type "CurveWire"','.SolidWireModel "False"','.AdvancedChainSelection "True"','.Add'):
            self.assertIn(required,macro)
        for forbidden in ('.Xcoordinate','.Ycoordinate','.Zcoordinate','.Segments','.Component'):
            self.assertNotIn(forbidden,macro)

class SolverSweepTests(unittest.TestCase):
 def test_fd_interval_145(self):
  m={'freq':145.0,'wires':[{'a':(0.,0.,0.),'b':(0.,0.,0.2),'r':0.001,'seg':5}],'sources':[],'loads':[],'path':'dummy.maa','name':'dummy'}
  t,a=emit(m)
  self.assertIn('Solver.FrequencyRange "0.13775", "0.15225"',t)
  self.assertIn('.AddSampleInterval "0.13775", "0.15225", "25", "Automatic", "False"',t)
  self.assertIn('.AddSampleInterval "0.145", "0.145", "1", "Single", "False"',t)
  self.assertEqual(a['fd_solver_sample_interval'],'Automatic')

class SurfaceMeshProgressTests(unittest.TestCase):
    def test_no_mesh_and_25(self):
        from maa_to_cst2026 import emit
        m={'path':'test.maa','freq':145,'wires':[{'a':(0,0,0),'b':(0,0,0.2),'r':0.001,'seg':9}],'sources':[],'loads':[],'name':'Test'}
        script,audit=emit(m)
        self.assertIn('.AddSampleInterval "0.13775", "0.15225", "25", "Automatic", "False"',script)
        self.assertNotIn('Mesh.',script)
        self.assertNotIn('With Mesh',script)
        self.assertNotIn('MeshSettings',script)
        self.assertEqual(audit['mesh_configuration'],'not_generated_user_controls_in_CST')
    def test_batch_progress(self):
        import tempfile
        from pathlib import Path
        from maa_to_cst2026 import batch
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'input';out=Path(temp)/'output';root.mkdir()
            for i in range(2):
                (root/f'{i}.maa').write_text('Ant\n145\n***Wires***\n1\n0,0,0,0,0,0.2,0.001,9\n',encoding='utf8')
            status=[]
            rows=batch(root,out,progress=lambda d,t,e:status.append((d,t)))
            self.assertEqual(status,[(0,2),(1,2),(2,2)])
            self.assertEqual(len(rows),2)
