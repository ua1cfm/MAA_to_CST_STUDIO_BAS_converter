﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.1.7
' Source: Big star(1).maa
' MMANA center frequency: 145 MHz
' Sweep: 137.75 .. 152.25 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' RLC LOADS ARE NOT IMPLEMENTED; SEE .audit.json
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.13775", "0.15225"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.13775", "0.15225", "25", "Automatic", "False"
        .AddSampleInterval "0.145", "0.145", "1", "Single", "False"
    End With


    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001"
        .Curve "MAA_Curves"
        .Point "0", "0", "0"
        .Point "0", "0", "10"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001"
        .Folder "MAA_Curves"
        .Radius "9"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "0", "0", "1560"
        .Point "0", "0", "3040"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "7.5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "0", "0", "3100"
        .Point "0", "0", "4440"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "6"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "0", "0", "3100"
        .Point "270", "0", "3100"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "270", "0", "3100"
        .Point "270", "0", "3040"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "270", "0", "3040"
        .Point "0", "0", "3040"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "0", "0", "1560"
        .Point "250", "0", "1560"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "250", "0", "1560"
        .Point "250", "0", "1500"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009"
        .Curve "MAA_Curves"
        .Point "250", "0", "1500"
        .Point "0", "0", "1500"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010"
        .Curve "MAA_Curves"
        .Point "0", "0", "0"
        .Point "450", "0", "-250"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "0", "0", "0"
        .Point "-450", "0", "-250"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "0", "0", "0"
        .Point "0", "450", "-250"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013"
        .Curve "MAA_Curves"
        .Point "0", "0", "0"
        .Point "0", "-450", "-250"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0014"
        .Curve "MAA_Curves"
        .Point "0", "0", "20"
        .Point "0", "0", "1500"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0014"
        .Folder "MAA_Curves"
        .Radius "9"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0014"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0015"
        .Curve "MAA_Curves"
        .Point "0", "0", "10"
        .Point "0", "0", "20"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0015"
        .Folder "MAA_Curves"
        .Radius "9"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0015"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0016"
        .Curve "MAA_Curves"
        .Point "0", "0", "10"
        .Point "10", "0", "10"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0016"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0016"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0017"
        .Curve "MAA_Curves"
        .Point "10", "0", "10"
        .Point "0", "0", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0017"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0017"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    MsgBox "Imported 17 wires and 0 port(s). See audit report for omitted loads/sources.", vbInformation, "MAA to CST 2026"
End Sub
