﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.1.8
' Source: TWINLOOP.MAA
' MMANA center frequency: 435 MHz
' Sweep: 413.25 .. 456.75 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' RLC loads: supported central ideal C, L and R; inspect audit for unsupported cases
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.41325", "0.45675"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.41325", "0.45675", "25", "Automatic", "False"
        .AddSampleInterval "0.435", "0.435", "1", "Single", "False"
    End With


    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001"
        .Curve "MAA_Curves"
        .Point "0", "-196", "-98"
        .Point "0", "0", "-98"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001"
        .Folder "MAA_Curves"
        .Radius "5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "0", "196", "-98"
        .Point "0", "196", "98"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "0", "196", "98"
        .Point "0", "0", "98"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "0", "-196", "98"
        .Point "0", "-196", "-98"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "0", "0", "98"
        .Point "0", "-196", "98"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "0", "0", "-98"
        .Point "0", "196", "-98"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007_1"
        .Curve "MAA_Curves"
        .Point "0", "0", "98"
        .Point "0", "0", "2"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007_1"
        .Folder "MAA_Curves"
        .Radius "5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007_2"
        .Curve "MAA_Curves"
        .Point "0", "0", "-2"
        .Point "0", "0", "-98"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007_2"
        .Folder "MAA_Curves"
        .Radius "5"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "1"
        .SetP1 "False", "0", "0", "2"
        .SetP2 "False", "0", "0", "-2"
        .Impedance "50"
        .Create
    End With

    MsgBox "Imported 7 wires and 1 port(s). See audit report for unsupported electrical elements.", vbInformation, "MAA to CST 2026"
End Sub
