﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.2.3
' Source: 144omni(3).maa
' MMANA center frequency: 145 MHz
' Sweep: 137.75 .. 152.25 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' Loads: ideal R,L,C at B/C/E; auto-segmented endpoint positions are approximate
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.13775", "0.15225"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.13775", "0.15225", "25", "Automatic", "False"
        .AddSampleInterval "0.145", "0.145", "1", "Single", "False"
    End With


    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001"
        .Curve "MAA_Curves"
        .Point "0", "60", "-145"
        .Point "0", "7.5", "-145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "0", "-58", "-145"
        .Point "0", "-150", "-62"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "0", "-150", "-62"
        .Point "0", "-150", "62"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "0", "-150", "62"
        .Point "0", "-62", "150"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "0", "-62", "150"
        .Point "0", "-6", "150"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "0", "62", "150"
        .Point "0", "150", "62"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "0", "150", "62"
        .Point "0", "150", "-62"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "0", "150", "-62"
        .Point "0", "60", "-145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009"
        .Curve "MAA_Curves"
        .Point "0", "62", "150"
        .Point "0", "6", "150"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010"
        .Curve "MAA_Curves"
        .Point "0", "7.5", "-145"
        .Point "0", "-58", "-145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "0", "60", "-145"
        .Point "0", "60", "-125"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "0", "60", "-125"
        .Point "0", "7.5", "-125"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013_1"
        .Curve "MAA_Curves"
        .Point "0", "7.5", "-125"
        .Point "0", "7.5", "-126.1285714"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013_1"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013_2"
        .Curve "MAA_Curves"
        .Point "0", "7.5", "-126.7285714"
        .Point "0", "7.5", "-134.7"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013_2"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013_3"
        .Curve "MAA_Curves"
        .Point "0", "7.5", "-135.3"
        .Point "0", "7.5", "-145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013_3"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013_3"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "1"
        .SetP1 "False", "0", "7.5", "-134.7"
        .SetP2 "False", "0", "7.5", "-135.3"
        .Impedance "50"
        .Create
    End With

    With LumpedElement
        .Reset
        .SetName "MAA_Load_1"
        .Folder "MAA_Loads"
        .SetType "RLCSerial"
        .SetR "0"
        .SetL "0"
        .SetC "1.8e-11"
        .SetGs "0"
        .SetI0 "1e-14"
        .SetT "300"
        .SetMonitor "True"
        .SetRadius "1"
        .CircuitFileName ""
        .CircuitId "1"
        .UseCopyOnly "True"
        .UseRelativePath "False"
        .SetP1 "False", "0", "7.5", "-126.1285714"
        .SetP2 "False", "0", "7.5", "-126.7285714"
        .SetInvert "False"
        .Wire ""
        .Position "end1"
        .Create
    End With

    MsgBox "Imported 13 wires, 1 port(s), 1 load command(s). Check CST Navigation Tree / Lumped Elements to verify actual creation.", vbInformation, "MAA to CST 2026"
End Sub
