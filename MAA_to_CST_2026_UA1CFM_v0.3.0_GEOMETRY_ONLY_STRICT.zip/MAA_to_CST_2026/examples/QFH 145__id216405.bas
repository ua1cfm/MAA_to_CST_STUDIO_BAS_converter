﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.1.8
' Source: QFH 145__id216405.maa
' MMANA center frequency: 145 MHz
' Sweep: 137.75 .. 152.25 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' RLC loads: supported central ideal C, L and R; inspect audit for unsupported cases
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.13775", "0.15225"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.13775", "0.15225", "25", "Automatic", "False"
        .AddSampleInterval "0.145", "0.145", "1", "Single", "False"
    End With


    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001_1"
        .Curve "MAA_Curves"
        .Point "3.88", "3.88", "473.47"
        .Point "0.22627417", "0.22627417", "473.47"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001_1"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001_2"
        .Curve "MAA_Curves"
        .Point "-0.22627417", "-0.22627417", "473.47"
        .Point "-3.88", "-3.88", "473.47"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001_2"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "0", "-182.61", "473.47"
        .Point "-3.88", "-3.88", "473.47"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "-182.61", "0", "473.47"
        .Point "-3.88", "-3.88", "473.47"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "0", "182.61", "473.47"
        .Point "3.88", "3.88", "473.47"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "182.61", "0", "473.47"
        .Point "3.88", "3.88", "473.47"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "0", "-182.61", "0"
        .Point "0", "0", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "-182.61", "0", "0"
        .Point "0", "0", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "0", "182.61", "0"
        .Point "0", "0", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009"
        .Curve "MAA_Curves"
        .Point "182.61", "0", "0"
        .Point "0", "0", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010"
        .Curve "MAA_Curves"
        .Point "91.31", "-158.14", "394.56"
        .Point "0", "-182.61", "473.47"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "91.31", "-158.14", "394.56"
        .Point "158.14", "-91.31", "315.65"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "182.61", "0", "236.74"
        .Point "158.14", "-91.31", "315.65"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013"
        .Curve "MAA_Curves"
        .Point "182.61", "0", "236.74"
        .Point "158.14", "91.31", "157.82"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0014"
        .Curve "MAA_Curves"
        .Point "91.31", "158.14", "78.91"
        .Point "158.14", "91.31", "157.82"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0014"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0014"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0015"
        .Curve "MAA_Curves"
        .Point "91.31", "158.14", "78.91"
        .Point "0", "182.61", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0015"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0015"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0016"
        .Curve "MAA_Curves"
        .Point "182.61", "0", "473.47"
        .Point "158.14", "91.31", "394.56"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0016"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0016"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0017"
        .Curve "MAA_Curves"
        .Point "91.31", "158.14", "315.65"
        .Point "158.14", "91.31", "394.56"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0017"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0017"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0018"
        .Curve "MAA_Curves"
        .Point "91.31", "158.14", "315.65"
        .Point "0", "182.61", "236.74"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0018"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0018"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0019"
        .Curve "MAA_Curves"
        .Point "-91.31", "158.14", "157.82"
        .Point "0", "182.61", "236.74"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0019"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0019"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0020"
        .Curve "MAA_Curves"
        .Point "-91.31", "158.14", "157.82"
        .Point "-158.14", "91.31", "78.91"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0020"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0020"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0021"
        .Curve "MAA_Curves"
        .Point "-182.61", "0", "0"
        .Point "-158.14", "91.31", "78.91"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0021"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0021"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0022"
        .Curve "MAA_Curves"
        .Point "-182.61", "0", "473.47"
        .Point "-158.14", "-91.31", "394.56"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0022"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0022"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0023"
        .Curve "MAA_Curves"
        .Point "-91.31", "-158.14", "315.65"
        .Point "-158.14", "-91.31", "394.56"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0023"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0023"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0024"
        .Curve "MAA_Curves"
        .Point "-91.31", "-158.14", "315.65"
        .Point "0", "-182.61", "236.74"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0024"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0024"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0025"
        .Curve "MAA_Curves"
        .Point "91.31", "-158.14", "157.82"
        .Point "0", "-182.61", "236.74"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0025"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0025"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0026"
        .Curve "MAA_Curves"
        .Point "91.31", "-158.14", "157.82"
        .Point "158.14", "-91.31", "78.91"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0026"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0026"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0027"
        .Curve "MAA_Curves"
        .Point "182.61", "0", "0"
        .Point "158.14", "-91.31", "78.91"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0027"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0027"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0028"
        .Curve "MAA_Curves"
        .Point "0", "182.61", "473.47"
        .Point "-91.31", "158.14", "394.56"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0028"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0028"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0029"
        .Curve "MAA_Curves"
        .Point "-158.14", "91.31", "315.65"
        .Point "-91.31", "158.14", "394.56"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0029"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0029"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0030"
        .Curve "MAA_Curves"
        .Point "-158.14", "91.31", "315.65"
        .Point "-182.61", "0", "236.74"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0030"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0030"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0031"
        .Curve "MAA_Curves"
        .Point "-158.14", "-91.31", "157.82"
        .Point "-182.61", "0", "236.74"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0031"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0031"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0032"
        .Curve "MAA_Curves"
        .Point "-158.14", "-91.31", "157.82"
        .Point "-91.31", "-158.14", "78.91"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0032"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0032"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0033"
        .Curve "MAA_Curves"
        .Point "0", "-182.61", "0"
        .Point "-91.31", "-158.14", "78.91"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0033"
        .Folder "MAA_Curves"
        .Radius "3"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0033"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "1"
        .SetP1 "False", "0.22627417", "0.22627417", "473.47"
        .SetP2 "False", "-0.22627417", "-0.22627417", "473.47"
        .Impedance "50"
        .Create
    End With

    MsgBox "Imported 33 wires and 1 port(s). See audit report for unsupported electrical elements.", vbInformation, "MAA to CST 2026"
End Sub
