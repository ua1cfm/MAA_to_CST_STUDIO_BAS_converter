﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.2.3
' Source: TEST_C_217pF_CENTER.maa
' MMANA center frequency: 145 MHz
' Sweep: 137.75 .. 152.25 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' Loads: ideal R,L,C at B/C/E; auto-segmented endpoint positions are approximate
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.13775", "0.15225"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.13775", "0.15225", "25", "Automatic", "False"
        .AddSampleInterval "0.145", "0.145", "1", "Single", "False"
    End With


    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001_1"
        .Curve "MAA_Curves"
        .Point "0", "0", "-100"
        .Point "0", "0", "-0.4"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001_1"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001_2"
        .Curve "MAA_Curves"
        .Point "0", "0", "0.4"
        .Point "0", "0", "100"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001_2"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With LumpedElement
        .Reset
        .SetName "MAA_Load_1"
        .Folder "MAA_Loads"
        .SetType "RLCSerial"
        .SetR "0"
        .SetL "0"
        .SetC "2.17e-10"
        .SetGs "0"
        .SetI0 "1e-14"
        .SetT "300"
        .SetMonitor "True"
        .SetRadius "1"
        .CircuitFileName ""
        .CircuitId "1"
        .UseCopyOnly "True"
        .UseRelativePath "False"
        .SetP1 "False", "0", "0", "-0.4"
        .SetP2 "False", "0", "0", "0.4"
        .SetInvert "False"
        .Wire ""
        .Position "end1"
        .Create
    End With

    MsgBox "Imported 1 wires, 0 port(s), 1 load command(s). Check CST Navigation Tree / Lumped Elements to verify actual creation.", vbInformation, "MAA to CST 2026"
End Sub
