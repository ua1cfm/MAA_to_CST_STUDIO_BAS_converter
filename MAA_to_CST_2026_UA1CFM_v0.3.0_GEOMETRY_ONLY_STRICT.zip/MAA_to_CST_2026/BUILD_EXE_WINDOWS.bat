@echo off
cd /d "%~dp0"
py -3 -m pip install pyinstaller
py -3 -m PyInstaller --noconfirm --onefile --windowed --name MAA_to_CST_Geometry_UA1CFM maa_to_cst2026.py
pause
