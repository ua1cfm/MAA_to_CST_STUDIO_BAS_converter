import unittest,sys,math,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from maa_to_cst2026 import emit,parse_file
class ElectricalTests(unittest.TestCase):
 def model(self,load):
  return {'name':'test','path':'test.maa','freq':145.,'wires':[{'a':(0,0,-0.1),'b':(0,0,0.1),'r':0.001,'seg':15}],'sources':[],'loads':[load]}
 def test_pure_capacitor(self):
  t,a=emit(self.model(['w1c','0','0','217','0']))
  self.assertEqual(a['load_imported'],1)
  self.assertIn('With LumpedElement',t)
  self.assertIn('.SetType "RLCSerial"',t)
  self.assertIn('.SetC "2.17e-10"',t)
  self.assertEqual(t.count('With Polygon3D'),2)
 def test_pure_inductor(self):
  t,a=emit(self.model(['w1c','0','2.2','0','0']))
  self.assertEqual(a['load_imported'],1)
  self.assertIn('.SetType "RLCSerial"',t)
 def test_resistor(self):
  t,a=emit(self.model(['w1c','1','75','0']))
  self.assertEqual(a['load_imported'],1)
  self.assertIn('.SetType "RLCSerial"',t)
 def test_parallel_lc_not_fake_series(self):
  t,a=emit(self.model(['w1c','0','2','100','0']))
  self.assertEqual(a['load_imported'],0)
  self.assertIn('parallel LC requires special circuit model',a['issues'][0]['reason'])
 def test_finite_q_not_faked(self):
  _,a=emit(self.model(['w1c','0','2','0','100']))
  self.assertEqual(a['load_imported'],0)
 def test_end_autoseg_approximate(self):
  m=self.model(['w1b','0','0','217','0']);m['wires'][0]['seg']=-1
  _,a=emit(m)
  self.assertEqual(a['load_imported'],1)
  self.assertTrue(a['end_pulse_position_is_approximate'])
 def test_mesh_absent(self):
  t,a=emit(self.model(['w1c','0','0','217','0']))
  self.assertNotIn('With Mesh',t)
  self.assertIn('"25", "Automatic"',t)
if __name__=='__main__':unittest.main()
