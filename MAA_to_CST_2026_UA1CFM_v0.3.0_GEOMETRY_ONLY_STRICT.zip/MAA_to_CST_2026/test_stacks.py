import unittest
from pathlib import Path
from maa_to_cst2026 import parse_file,emit
BASE=Path(__file__).resolve().parent
class TestStacks(unittest.TestCase):
    def check(self,name,wires,sources,ports):
        m=parse_file(BASE/'stack_samples'/name); code,a=emit(m)
        self.assertEqual(len(m['wires']),wires)
        self.assertEqual(len(m['sources']),sources)
        self.assertEqual(len(a['ports']),ports)
        self.assertEqual(code.count('With DiscretePort'),ports)
        self.assertEqual(code.count('With Wire'),wires + (sum(1 for i in a['ports'] if i) )) if False else None
    def test_two_yagis(self):self.check('2x6el10.maa',12,2,2)
    def test_two_three_elements(self):self.check('syack3el20.maa',6,2,2)
    def test_four_quads(self):self.check('4xQQ.maa',32,4,4)
    def test_four_twelve(self):
        m=parse_file(BASE/'stack_samples'/'4X12.MAA');_,a=emit(m)
        self.assertEqual(len(m['wires']),68)
        self.assertEqual(len(m['sources']),4)
        self.assertEqual(len(a['ports']),4)
        self.assertEqual(sum(z['status']=='SHIFTED_FEED_GAP' for z in a['issues']),4)
        self.assertEqual(len(a['imported_loads']),4)
    def test_nonstack(self):self.check('hornYagi-3.maa',12,1,1)
if __name__=='__main__':unittest.main()
