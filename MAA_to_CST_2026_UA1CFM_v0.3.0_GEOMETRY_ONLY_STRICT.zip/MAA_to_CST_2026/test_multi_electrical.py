import unittest
from pathlib import Path
from maa_to_cst2026 import parse_file,emit
class MultiTests(unittest.TestCase):
 def test_gamma_source_and_load(self):
  source=Path('/mnt/data/144omni(3).maa')
  if not source.exists():self.skipTest('sample not mounted')
  text,audit=emit(parse_file(source))
  self.assertEqual((audit['port_count'],audit['load_imported']),(1,1))
  self.assertIn('.SetC "1.8e-11"',text)
  self.assertEqual(text.count('With Polygon3D'),15)
  self.assertTrue(audit['end_pulse_position_is_approximate'])
  self.assertIn('.SetP1 "False", "0", "7.5",',text)
  self.assertNotIn('.SetP1 "True"',text)
 def test_multiple_elements_on_wire(self):
  model={'path':'test.maa','freq':145.0,'name':'test','wires':[{'a':(0,0,0),'b':(0,0,1),'r':.001,'seg':15}],'sources':[['w1c','0','1']],'loads':[['w1b','0','0','18','0'],['w1e','0','0','18','0']]}
  text,audit=emit(model)
  self.assertEqual(audit['port_count'],1)
  self.assertEqual(audit['load_imported'],2)
  self.assertEqual(text.count('With Polygon3D'),4)
  self.assertNotIn('With Mesh',text)
if __name__=='__main__':unittest.main()
