﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.2.6
' Source: syack3el20.maa
' MMANA center frequency: 14.05 MHz
' Sweep: 13.3475 .. 14.7525 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' Loads: ideal R,L,C at B/C/E; auto-segmented endpoint positions are approximate
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.0133475", "0.0147525"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.0133475", "0.0147525", "25", "Automatic", "False"
        .AddSampleInterval "0.01405", "0.01405", "1", "Single", "False"
    End With

' STACK: {'horizontal': 2, 'vertical': 1, 'horizontal_spacing_m': 21.338078, 'vertical_spacing_m': 21.338078, 'placement_mode': 0, 'copies': 2, 'base_wires': 3, 'expanded': True}

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001_1"
        .Curve "MAA_Curves"
        .Point "0", "-15984.039", "0"
        .Point "0", "-10669.439", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001_1"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001_2"
        .Curve "MAA_Curves"
        .Point "0", "-10668.639", "0"
        .Point "0", "-5354.039", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001_2"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "2600", "-15669.039", "0"
        .Point "2600", "-5669.039", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "-2600", "-16119.039", "0"
        .Point "-2600", "-5219.039", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004_1"
        .Curve "MAA_Curves"
        .Point "0", "5354.039", "0"
        .Point "0", "10668.639", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004_1"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004_2"
        .Curve "MAA_Curves"
        .Point "0", "10669.439", "0"
        .Point "0", "15984.039", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004_2"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "2600", "5669.039", "0"
        .Point "2600", "15669.039", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "-2600", "5219.039", "0"
        .Point "-2600", "16119.039", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "1"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "1"
        .SetP1 "False", "0", "-10669.439", "0"
        .SetP2 "False", "0", "-10668.639", "0"
        .Impedance "50"
        .Create
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "2"
        .SetP1 "False", "0", "10668.639", "0"
        .SetP2 "False", "0", "10669.439", "0"
        .Impedance "50"
        .Create
    End With

    MsgBox "Imported 6 wires, 2 port(s), 0 load command(s). Check CST Navigation Tree / Lumped Elements to verify actual creation.", vbInformation, "MAA to CST 2026"
End Sub
