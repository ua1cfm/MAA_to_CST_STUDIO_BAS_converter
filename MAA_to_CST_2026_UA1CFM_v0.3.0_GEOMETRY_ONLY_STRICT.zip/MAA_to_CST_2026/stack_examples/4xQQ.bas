﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.2.6
' Source: 4xQQ.maa
' MMANA center frequency: 14.05 MHz
' Sweep: 13.3475 .. 14.7525 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' Loads: ideal R,L,C at B/C/E; auto-segmented endpoint positions are approximate
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.0133475", "0.0147525"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.0133475", "0.0147525", "25", "Automatic", "False"
        .AddSampleInterval "0.01405", "0.01405", "1", "Single", "False"
    End With

' STACK: {'horizontal': 2, 'vertical': 2, 'horizontal_spacing_m': 10.669039, 'vertical_spacing_m': 10.669039, 'placement_mode': 0, 'copies': 4, 'base_wires': 8, 'expanded': True}

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001_1"
        .Curve "MAA_Curves"
        .Point "0", "-8015.0195", "-8015.0195"
        .Point "0", "-5334.8395", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001_1"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001_2"
        .Curve "MAA_Curves"
        .Point "0", "-5334.1995", "-8015.0195"
        .Point "0", "-2654.0195", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001_2"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "0", "-2654.0195", "-8015.0195"
        .Point "0", "-2654.0195", "-2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "0", "-2654.0195", "-2654.0195"
        .Point "0", "-8015.0195", "-2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "0", "-8015.0195", "-2654.0195"
        .Point "0", "-8015.0195", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "-2590", "-8133.2695", "-8133.2695"
        .Point "-2590", "-2535.7695", "-8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "-2590", "-2535.7695", "-8133.2695"
        .Point "-2590", "-2535.7695", "-2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "-2590", "-2535.7695", "-2535.7695"
        .Point "-2590", "-8133.2695", "-2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "-2590", "-8133.2695", "-2535.7695"
        .Point "-2590", "-8133.2695", "-8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009_1"
        .Curve "MAA_Curves"
        .Point "0", "2654.0195", "-8015.0195"
        .Point "0", "5334.1995", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009_1"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009_2"
        .Curve "MAA_Curves"
        .Point "0", "5334.8395", "-8015.0195"
        .Point "0", "8015.0195", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009_2"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010"
        .Curve "MAA_Curves"
        .Point "0", "8015.0195", "-8015.0195"
        .Point "0", "8015.0195", "-2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "0", "8015.0195", "-2654.0195"
        .Point "0", "2654.0195", "-2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "0", "2654.0195", "-2654.0195"
        .Point "0", "2654.0195", "-8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013"
        .Curve "MAA_Curves"
        .Point "-2590", "2535.7695", "-8133.2695"
        .Point "-2590", "8133.2695", "-8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0014"
        .Curve "MAA_Curves"
        .Point "-2590", "8133.2695", "-8133.2695"
        .Point "-2590", "8133.2695", "-2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0014"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0014"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0015"
        .Curve "MAA_Curves"
        .Point "-2590", "8133.2695", "-2535.7695"
        .Point "-2590", "2535.7695", "-2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0015"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0015"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0016"
        .Curve "MAA_Curves"
        .Point "-2590", "2535.7695", "-2535.7695"
        .Point "-2590", "2535.7695", "-8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0016"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0016"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0017_1"
        .Curve "MAA_Curves"
        .Point "0", "-8015.0195", "2654.0195"
        .Point "0", "-5334.8395", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0017_1"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0017_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0017_2"
        .Curve "MAA_Curves"
        .Point "0", "-5334.1995", "2654.0195"
        .Point "0", "-2654.0195", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0017_2"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0017_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0018"
        .Curve "MAA_Curves"
        .Point "0", "-2654.0195", "2654.0195"
        .Point "0", "-2654.0195", "8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0018"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0018"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0019"
        .Curve "MAA_Curves"
        .Point "0", "-2654.0195", "8015.0195"
        .Point "0", "-8015.0195", "8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0019"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0019"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0020"
        .Curve "MAA_Curves"
        .Point "0", "-8015.0195", "8015.0195"
        .Point "0", "-8015.0195", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0020"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0020"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0021"
        .Curve "MAA_Curves"
        .Point "-2590", "-8133.2695", "2535.7695"
        .Point "-2590", "-2535.7695", "2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0021"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0021"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0022"
        .Curve "MAA_Curves"
        .Point "-2590", "-2535.7695", "2535.7695"
        .Point "-2590", "-2535.7695", "8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0022"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0022"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0023"
        .Curve "MAA_Curves"
        .Point "-2590", "-2535.7695", "8133.2695"
        .Point "-2590", "-8133.2695", "8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0023"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0023"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0024"
        .Curve "MAA_Curves"
        .Point "-2590", "-8133.2695", "8133.2695"
        .Point "-2590", "-8133.2695", "2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0024"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0024"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0025_1"
        .Curve "MAA_Curves"
        .Point "0", "2654.0195", "2654.0195"
        .Point "0", "5334.1995", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0025_1"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0025_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0025_2"
        .Curve "MAA_Curves"
        .Point "0", "5334.8395", "2654.0195"
        .Point "0", "8015.0195", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0025_2"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0025_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0026"
        .Curve "MAA_Curves"
        .Point "0", "8015.0195", "2654.0195"
        .Point "0", "8015.0195", "8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0026"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0026"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0027"
        .Curve "MAA_Curves"
        .Point "0", "8015.0195", "8015.0195"
        .Point "0", "2654.0195", "8015.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0027"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0027"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0028"
        .Curve "MAA_Curves"
        .Point "0", "2654.0195", "8015.0195"
        .Point "0", "2654.0195", "2654.0195"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0028"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0028"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0029"
        .Curve "MAA_Curves"
        .Point "-2590", "2535.7695", "2535.7695"
        .Point "-2590", "8133.2695", "2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0029"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0029"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0030"
        .Curve "MAA_Curves"
        .Point "-2590", "8133.2695", "2535.7695"
        .Point "-2590", "8133.2695", "8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0030"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0030"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0031"
        .Curve "MAA_Curves"
        .Point "-2590", "8133.2695", "8133.2695"
        .Point "-2590", "2535.7695", "8133.2695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0031"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0031"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0032"
        .Curve "MAA_Curves"
        .Point "-2590", "2535.7695", "8133.2695"
        .Point "-2590", "2535.7695", "2535.7695"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0032"
        .Folder "MAA_Curves"
        .Radius "0.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0032"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "1"
        .SetP1 "False", "0", "-5334.8395", "-8015.0195"
        .SetP2 "False", "0", "-5334.1995", "-8015.0195"
        .Impedance "50"
        .Create
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "2"
        .SetP1 "False", "0", "5334.1995", "-8015.0195"
        .SetP2 "False", "0", "5334.8395", "-8015.0195"
        .Impedance "50"
        .Create
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "3"
        .SetP1 "False", "0", "-5334.8395", "2654.0195"
        .SetP2 "False", "0", "-5334.1995", "2654.0195"
        .Impedance "50"
        .Create
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "4"
        .SetP1 "False", "0", "5334.1995", "2654.0195"
        .SetP2 "False", "0", "5334.8395", "2654.0195"
        .Impedance "50"
        .Create
    End With

    MsgBox "Imported 32 wires, 4 port(s), 0 load command(s). Check CST Navigation Tree / Lumped Elements to verify actual creation.", vbInformation, "MAA to CST 2026"
End Sub
