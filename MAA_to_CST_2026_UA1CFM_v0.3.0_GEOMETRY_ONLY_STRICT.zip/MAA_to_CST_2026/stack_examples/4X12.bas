﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.2.6
' Source: 4X12.MAA
' MMANA center frequency: 435 MHz
' Sweep: 413.25 .. 456.75 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' Loads: ideal R,L,C at B/C/E; auto-segmented endpoint positions are approximate
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.41325", "0.45675"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.41325", "0.45675", "25", "Automatic", "False"
        .AddSampleInterval "0.435", "0.435", "1", "Single", "False"
    End With

' STACK: {'horizontal': 4, 'vertical': 1, 'horizontal_spacing_m': 0.689195, 'vertical_spacing_m': 0.689195, 'placement_mode': 0, 'copies': 4, 'base_wires': 17, 'expanded': True}

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001"
        .Curve "MAA_Curves"
        .Point "0", "-1033.7925", "-154"
        .Point "0", "-1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "-110", "-1033.7925", "-175"
        .Point "-110", "-1033.7925", "175"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "70", "-1033.7925", "-147.5"
        .Point "70", "-1033.7925", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "150", "-1033.7925", "-147.5"
        .Point "150", "-1033.7925", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "240", "-1033.7925", "-145"
        .Point "240", "-1033.7925", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "360", "-1033.7925", "-145"
        .Point "360", "-1033.7925", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "500", "-1033.7925", "-140"
        .Point "500", "-1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "650", "-1033.7925", "-140"
        .Point "650", "-1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009"
        .Curve "MAA_Curves"
        .Point "820", "-1033.7925", "-140"
        .Point "820", "-1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010"
        .Curve "MAA_Curves"
        .Point "990", "-1033.7925", "-140"
        .Point "990", "-1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "1150", "-1033.7925", "-135"
        .Point "1150", "-1033.7925", "135"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "1350", "-1033.7925", "-130"
        .Point "1350", "-1033.7925", "130"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013_1"
        .Curve "MAA_Curves"
        .Point "-10", "-1033.7925", "0"
        .Point "-10", "-1033.7925", "-3.897142857"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013_1"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0013_2"
        .Curve "MAA_Curves"
        .Point "-10", "-1033.7925", "-5.817142857"
        .Point "-10", "-1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0013_2"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0013_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0014"
        .Curve "MAA_Curves"
        .Point "0", "-1033.7925", "0"
        .Point "0", "-1033.7925", "154"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0014"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0014"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0015"
        .Curve "MAA_Curves"
        .Point "0", "-1033.7925", "-68"
        .Point "0", "-1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0015"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0015"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0016"
        .Curve "MAA_Curves"
        .Point "-10", "-1033.7925", "-68"
        .Point "0", "-1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0016"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0016"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0017_1"
        .Curve "MAA_Curves"
        .Point "-10", "-1033.7925", "0"
        .Point "-6.15", "-1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0017_1"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0017_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0017_2"
        .Curve "MAA_Curves"
        .Point "-5.85", "-1033.7925", "0"
        .Point "0", "-1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0017_2"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0017_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0018"
        .Curve "MAA_Curves"
        .Point "0", "-344.5975", "-154"
        .Point "0", "-344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0018"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0018"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0019"
        .Curve "MAA_Curves"
        .Point "-110", "-344.5975", "-175"
        .Point "-110", "-344.5975", "175"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0019"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0019"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0020"
        .Curve "MAA_Curves"
        .Point "70", "-344.5975", "-147.5"
        .Point "70", "-344.5975", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0020"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0020"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0021"
        .Curve "MAA_Curves"
        .Point "150", "-344.5975", "-147.5"
        .Point "150", "-344.5975", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0021"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0021"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0022"
        .Curve "MAA_Curves"
        .Point "240", "-344.5975", "-145"
        .Point "240", "-344.5975", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0022"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0022"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0023"
        .Curve "MAA_Curves"
        .Point "360", "-344.5975", "-145"
        .Point "360", "-344.5975", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0023"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0023"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0024"
        .Curve "MAA_Curves"
        .Point "500", "-344.5975", "-140"
        .Point "500", "-344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0024"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0024"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0025"
        .Curve "MAA_Curves"
        .Point "650", "-344.5975", "-140"
        .Point "650", "-344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0025"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0025"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0026"
        .Curve "MAA_Curves"
        .Point "820", "-344.5975", "-140"
        .Point "820", "-344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0026"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0026"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0027"
        .Curve "MAA_Curves"
        .Point "990", "-344.5975", "-140"
        .Point "990", "-344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0027"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0027"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0028"
        .Curve "MAA_Curves"
        .Point "1150", "-344.5975", "-135"
        .Point "1150", "-344.5975", "135"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0028"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0028"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0029"
        .Curve "MAA_Curves"
        .Point "1350", "-344.5975", "-130"
        .Point "1350", "-344.5975", "130"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0029"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0029"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0030_1"
        .Curve "MAA_Curves"
        .Point "-10", "-344.5975", "0"
        .Point "-10", "-344.5975", "-3.897142857"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0030_1"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0030_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0030_2"
        .Curve "MAA_Curves"
        .Point "-10", "-344.5975", "-5.817142857"
        .Point "-10", "-344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0030_2"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0030_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0031"
        .Curve "MAA_Curves"
        .Point "0", "-344.5975", "0"
        .Point "0", "-344.5975", "154"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0031"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0031"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0032"
        .Curve "MAA_Curves"
        .Point "0", "-344.5975", "-68"
        .Point "0", "-344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0032"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0032"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0033"
        .Curve "MAA_Curves"
        .Point "-10", "-344.5975", "-68"
        .Point "0", "-344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0033"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0033"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0034_1"
        .Curve "MAA_Curves"
        .Point "-10", "-344.5975", "0"
        .Point "-6.15", "-344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0034_1"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0034_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0034_2"
        .Curve "MAA_Curves"
        .Point "-5.85", "-344.5975", "0"
        .Point "0", "-344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0034_2"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0034_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0035"
        .Curve "MAA_Curves"
        .Point "0", "344.5975", "-154"
        .Point "0", "344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0035"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0035"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0036"
        .Curve "MAA_Curves"
        .Point "-110", "344.5975", "-175"
        .Point "-110", "344.5975", "175"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0036"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0036"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0037"
        .Curve "MAA_Curves"
        .Point "70", "344.5975", "-147.5"
        .Point "70", "344.5975", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0037"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0037"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0038"
        .Curve "MAA_Curves"
        .Point "150", "344.5975", "-147.5"
        .Point "150", "344.5975", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0038"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0038"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0039"
        .Curve "MAA_Curves"
        .Point "240", "344.5975", "-145"
        .Point "240", "344.5975", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0039"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0039"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0040"
        .Curve "MAA_Curves"
        .Point "360", "344.5975", "-145"
        .Point "360", "344.5975", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0040"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0040"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0041"
        .Curve "MAA_Curves"
        .Point "500", "344.5975", "-140"
        .Point "500", "344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0041"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0041"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0042"
        .Curve "MAA_Curves"
        .Point "650", "344.5975", "-140"
        .Point "650", "344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0042"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0042"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0043"
        .Curve "MAA_Curves"
        .Point "820", "344.5975", "-140"
        .Point "820", "344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0043"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0043"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0044"
        .Curve "MAA_Curves"
        .Point "990", "344.5975", "-140"
        .Point "990", "344.5975", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0044"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0044"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0045"
        .Curve "MAA_Curves"
        .Point "1150", "344.5975", "-135"
        .Point "1150", "344.5975", "135"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0045"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0045"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0046"
        .Curve "MAA_Curves"
        .Point "1350", "344.5975", "-130"
        .Point "1350", "344.5975", "130"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0046"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0046"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0047_1"
        .Curve "MAA_Curves"
        .Point "-10", "344.5975", "0"
        .Point "-10", "344.5975", "-3.897142857"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0047_1"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0047_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0047_2"
        .Curve "MAA_Curves"
        .Point "-10", "344.5975", "-5.817142857"
        .Point "-10", "344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0047_2"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0047_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0048"
        .Curve "MAA_Curves"
        .Point "0", "344.5975", "0"
        .Point "0", "344.5975", "154"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0048"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0048"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0049"
        .Curve "MAA_Curves"
        .Point "0", "344.5975", "-68"
        .Point "0", "344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0049"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0049"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0050"
        .Curve "MAA_Curves"
        .Point "-10", "344.5975", "-68"
        .Point "0", "344.5975", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0050"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0050"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0051_1"
        .Curve "MAA_Curves"
        .Point "-10", "344.5975", "0"
        .Point "-6.15", "344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0051_1"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0051_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0051_2"
        .Curve "MAA_Curves"
        .Point "-5.85", "344.5975", "0"
        .Point "0", "344.5975", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0051_2"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0051_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0052"
        .Curve "MAA_Curves"
        .Point "0", "1033.7925", "-154"
        .Point "0", "1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0052"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0052"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0053"
        .Curve "MAA_Curves"
        .Point "-110", "1033.7925", "-175"
        .Point "-110", "1033.7925", "175"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0053"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0053"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0054"
        .Curve "MAA_Curves"
        .Point "70", "1033.7925", "-147.5"
        .Point "70", "1033.7925", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0054"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0054"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0055"
        .Curve "MAA_Curves"
        .Point "150", "1033.7925", "-147.5"
        .Point "150", "1033.7925", "147.5"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0055"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0055"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0056"
        .Curve "MAA_Curves"
        .Point "240", "1033.7925", "-145"
        .Point "240", "1033.7925", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0056"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0056"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0057"
        .Curve "MAA_Curves"
        .Point "360", "1033.7925", "-145"
        .Point "360", "1033.7925", "145"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0057"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0057"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0058"
        .Curve "MAA_Curves"
        .Point "500", "1033.7925", "-140"
        .Point "500", "1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0058"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0058"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0059"
        .Curve "MAA_Curves"
        .Point "650", "1033.7925", "-140"
        .Point "650", "1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0059"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0059"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0060"
        .Curve "MAA_Curves"
        .Point "820", "1033.7925", "-140"
        .Point "820", "1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0060"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0060"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0061"
        .Curve "MAA_Curves"
        .Point "990", "1033.7925", "-140"
        .Point "990", "1033.7925", "140"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0061"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0061"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0062"
        .Curve "MAA_Curves"
        .Point "1150", "1033.7925", "-135"
        .Point "1150", "1033.7925", "135"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0062"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0062"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0063"
        .Curve "MAA_Curves"
        .Point "1350", "1033.7925", "-130"
        .Point "1350", "1033.7925", "130"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0063"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0063"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0064_1"
        .Curve "MAA_Curves"
        .Point "-10", "1033.7925", "0"
        .Point "-10", "1033.7925", "-3.897142857"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0064_1"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0064_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0064_2"
        .Curve "MAA_Curves"
        .Point "-10", "1033.7925", "-5.817142857"
        .Point "-10", "1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0064_2"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0064_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0065"
        .Curve "MAA_Curves"
        .Point "0", "1033.7925", "0"
        .Point "0", "1033.7925", "154"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0065"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0065"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0066"
        .Curve "MAA_Curves"
        .Point "0", "1033.7925", "-68"
        .Point "0", "1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0066"
        .Folder "MAA_Curves"
        .Radius "4.8"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0066"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0067"
        .Curve "MAA_Curves"
        .Point "-10", "1033.7925", "-68"
        .Point "0", "1033.7925", "-68"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0067"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0067"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0068_1"
        .Curve "MAA_Curves"
        .Point "-10", "1033.7925", "0"
        .Point "-6.15", "1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0068_1"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0068_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0068_2"
        .Curve "MAA_Curves"
        .Point "-5.85", "1033.7925", "0"
        .Point "0", "1033.7925", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0068_2"
        .Folder "MAA_Curves"
        .Radius "2.4"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0068_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "1"
        .SetP1 "False", "-6.15", "-1033.7925", "0"
        .SetP2 "False", "-5.85", "-1033.7925", "0"
        .Impedance "50"
        .Create
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "2"
        .SetP1 "False", "-6.15", "-344.5975", "0"
        .SetP2 "False", "-5.85", "-344.5975", "0"
        .Impedance "50"
        .Create
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "3"
        .SetP1 "False", "-6.15", "344.5975", "0"
        .SetP2 "False", "-5.85", "344.5975", "0"
        .Impedance "50"
        .Create
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "4"
        .SetP1 "False", "-6.15", "1033.7925", "0"
        .SetP2 "False", "-5.85", "1033.7925", "0"
        .Impedance "50"
        .Create
    End With

    With LumpedElement
        .Reset
        .SetName "MAA_Load_1"
        .Folder "MAA_Loads"
        .SetType "RLCSerial"
        .SetR "0"
        .SetL "0"
        .SetC "3.78e-12"
        .SetGs "0"
        .SetI0 "1e-14"
        .SetT "300"
        .SetMonitor "True"
        .SetRadius "1"
        .CircuitFileName ""
        .CircuitId "1"
        .UseCopyOnly "True"
        .UseRelativePath "False"
        .SetP1 "False", "-10", "-1033.7925", "-3.897142857"
        .SetP2 "False", "-10", "-1033.7925", "-5.817142857"
        .SetInvert "False"
        .Wire ""
        .Position "end1"
        .Create
    End With

    With LumpedElement
        .Reset
        .SetName "MAA_Load_2"
        .Folder "MAA_Loads"
        .SetType "RLCSerial"
        .SetR "0"
        .SetL "0"
        .SetC "3.78e-12"
        .SetGs "0"
        .SetI0 "1e-14"
        .SetT "300"
        .SetMonitor "True"
        .SetRadius "1"
        .CircuitFileName ""
        .CircuitId "1"
        .UseCopyOnly "True"
        .UseRelativePath "False"
        .SetP1 "False", "-10", "-344.5975", "-3.897142857"
        .SetP2 "False", "-10", "-344.5975", "-5.817142857"
        .SetInvert "False"
        .Wire ""
        .Position "end1"
        .Create
    End With

    With LumpedElement
        .Reset
        .SetName "MAA_Load_3"
        .Folder "MAA_Loads"
        .SetType "RLCSerial"
        .SetR "0"
        .SetL "0"
        .SetC "3.78e-12"
        .SetGs "0"
        .SetI0 "1e-14"
        .SetT "300"
        .SetMonitor "True"
        .SetRadius "1"
        .CircuitFileName ""
        .CircuitId "1"
        .UseCopyOnly "True"
        .UseRelativePath "False"
        .SetP1 "False", "-10", "344.5975", "-3.897142857"
        .SetP2 "False", "-10", "344.5975", "-5.817142857"
        .SetInvert "False"
        .Wire ""
        .Position "end1"
        .Create
    End With

    With LumpedElement
        .Reset
        .SetName "MAA_Load_4"
        .Folder "MAA_Loads"
        .SetType "RLCSerial"
        .SetR "0"
        .SetL "0"
        .SetC "3.78e-12"
        .SetGs "0"
        .SetI0 "1e-14"
        .SetT "300"
        .SetMonitor "True"
        .SetRadius "1"
        .CircuitFileName ""
        .CircuitId "1"
        .UseCopyOnly "True"
        .UseRelativePath "False"
        .SetP1 "False", "-10", "1033.7925", "-3.897142857"
        .SetP2 "False", "-10", "1033.7925", "-5.817142857"
        .SetInvert "False"
        .Wire ""
        .Position "end1"
        .Create
    End With

    MsgBox "Imported 68 wires, 4 port(s), 4 load command(s). Check CST Navigation Tree / Lumped Elements to verify actual creation.", vbInformation, "MAA to CST 2026"
End Sub
