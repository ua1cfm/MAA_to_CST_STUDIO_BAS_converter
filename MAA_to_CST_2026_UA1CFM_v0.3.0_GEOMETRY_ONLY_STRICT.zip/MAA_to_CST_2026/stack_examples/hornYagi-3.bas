﻿' MAA -> CST Studio Suite 2026 | UA1CFM | 2026
' Generator version 0.2.6
' Source: hornYagi-3.maa
' MMANA center frequency: 145 MHz
' Sweep: 137.75 .. 152.25 MHz (+/- 5%)
' Polygon3D -> CurveWire from user-supplied CST 2026 History List.
' Loads: ideal R,L,C at B/C/E; auto-segmented endpoint positions are approximate
' Use a NEW EMPTY Microwave Studio project in CST 2026.
Sub Main()
    With Units
        .Geometry "mm"
        .Frequency "GHz"
    End With
    Solver.FrequencyRange "0.13775", "0.15225"

    With FDSolver
        .Reset
        .SetMethod "Surface", "General purpose"
        .OrderSrf "First"
        .Stimulation "All", "All"
        .SweepMinimumSamples "10"
        .SetNumberOfResultDataSamples "1001"
        .SetResultDataSamplingMode "Automatic"
        .AddSampleInterval "0.13775", "0.15225", "25", "Automatic", "False"
        .AddSampleInterval "0.145", "0.145", "1", "Single", "False"
    End With

' STACK: {'horizontal': 1, 'vertical': 1, 'horizontal_spacing_m': 0.0, 'vertical_spacing_m': 0.0, 'placement_mode': 0, 'copies': 1, 'base_wires': 12, 'expanded': False}

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0001"
        .Curve "MAA_Curves"
        .Point "-400", "562", "0"
        .Point "-400", "-562", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0001"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0001"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0002"
        .Curve "MAA_Curves"
        .Point "300", "467.5", "-100"
        .Point "300", "-467.5", "-100"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0002"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0002"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0003"
        .Curve "MAA_Curves"
        .Point "300", "467.5", "100"
        .Point "300", "-467.5", "100"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0003"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0003"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0004"
        .Curve "MAA_Curves"
        .Point "600", "465", "250"
        .Point "600", "-465", "250"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0004"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0004"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0005"
        .Curve "MAA_Curves"
        .Point "600", "465", "-250"
        .Point "600", "-465", "-250"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0005"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0005"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0006"
        .Curve "MAA_Curves"
        .Point "950", "462.5", "-400"
        .Point "950", "-462.5", "-400"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0006"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0006"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0007"
        .Curve "MAA_Curves"
        .Point "950", "462.5", "400"
        .Point "950", "-462.5", "400"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0007"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0007"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0008"
        .Curve "MAA_Curves"
        .Point "1400", "460", "550"
        .Point "1400", "-460", "550"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0008"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0008"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0009"
        .Curve "MAA_Curves"
        .Point "1400", "460", "-550"
        .Point "1400", "-460", "-550"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0009"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0009"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010_1"
        .Curve "MAA_Curves"
        .Point "0", "493", "0"
        .Point "0", "0.8", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010_1"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010_1"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0010_2"
        .Curve "MAA_Curves"
        .Point "0", "-0.8", "0"
        .Point "0", "-493", "0"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0010_2"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0010_2"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0011"
        .Curve "MAA_Curves"
        .Point "-400", "562", "400"
        .Point "-400", "-562", "400"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0011"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0011"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With Polygon3D
        .Reset
        .Version 10
        .Name "poly_W0012"
        .Curve "MAA_Curves"
        .Point "-400", "562", "-400"
        .Point "-400", "-562", "-400"
        .Create
    End With

    With Wire
        .Reset
        .Name "wire_W0012"
        .Folder "MAA_Curves"
        .Radius "2"
        .Type "CurveWire"
        .Curve "MAA_Curves:poly_W0012"
        .Material "PEC"
        .SolidWireModel "False"
        .Termination "Natural"
        .Mitering "NewMiter"
        .AdvancedChainSelection "True"
        .Add
    End With

    With DiscretePort
        .Reset
        .Type "SParameter"
        .PortNumber "1"
        .SetP1 "False", "0", "0.8", "0"
        .SetP2 "False", "0", "-0.8", "0"
        .Impedance "50"
        .Create
    End With

    MsgBox "Imported 12 wires, 1 port(s), 0 load command(s). Check CST Navigation Tree / Lumped Elements to verify actual creation.", vbInformation, "MAA to CST 2026"
End Sub
